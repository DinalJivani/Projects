//
//  main.m
//  CoreData
//
//  Created by EbitNHP-i1 on 10/09/18.
//  Copyright © 2018 EbitNHP-i1. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
