//
//  UserTableViewCell.m
//  CoreData
//
//  Created by EbitNHP-i1 on 10/09/18.
//  Copyright © 2018 EbitNHP-i1. All rights reserved.
//

#import "UserTableViewCell.h"

@implementation UserTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
