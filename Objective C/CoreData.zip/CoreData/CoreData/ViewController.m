//
//  ViewController.m
//  CoreData
//
//  Created by EbitNHP-i1 on 10/09/18.
//  Copyright © 2018 EbitNHP-i1. All rights reserved.
//

#import "ViewController.h"
#import "User+CoreDataProperties.h"
#import "UserTableViewCell.h"
#import <CoreData/CoreData.h>
#include "AppDelegate.h"

@interface ViewController ()<UITableViewDelegate,UITableViewDataSource>
@property (weak, nonatomic) IBOutlet UITextField *txtName;
@property (weak, nonatomic) IBOutlet UITextField *txtCity;
@property (weak, nonatomic) IBOutlet UITextField *txtEmail;
@property (weak, nonatomic) IBOutlet UITableView *tblUser;
@property (strong, nonatomic) NSManagedObjectContext *contex;
@property (strong, nonatomic) NSMutableDictionary *dicUser;
@property (strong, nonatomic) NSMutableArray *arrUser;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.dicUser = [[NSMutableDictionary alloc] init];
    self.arrUser = [[NSMutableArray alloc] init];
    self.contex = ((AppDelegate*)[[UIApplication sharedApplication] delegate]).persistentContainer.viewContext;
    _tblUser.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
    [self FetchAllRecord];
    // Do any additional setup after loading the view, typically from a nib.
}
- (void)FetchAllRecord {
    self.arrUser = [NSMutableArray new];
    self.dicUser = [NSMutableDictionary new];
    
    NSFetchRequest *request = [NSFetchRequest fetchRequestWithEntityName:@"User"];
    NSEntityDescription *entityDesc = [NSEntityDescription entityForName:@"User" inManagedObjectContext:self.contex];
    request.entity = entityDesc;
    NSArray *fetchedObjects = [[NSArray alloc] init];
    NSError *error;
    fetchedObjects = [self.contex executeFetchRequest:request error:&error];
    
    if (error != nil) {
        NSLog(@"%@",error);
    } else {
        if (fetchedObjects.count > 0) {
            for (int i=0; i<[fetchedObjects count]; i++) {
                self.dicUser = [NSMutableDictionary new];
                NSManagedObject *result = fetchedObjects[i];
                
                [self.dicUser setValue:[result valueForKey:@"user_Name"] forKey:@"user_Name"];
                [self.dicUser setValue:[result valueForKey:@"user_City"] forKey:@"user_City"];
                [self.dicUser setValue:[result valueForKey:@"user_Email"] forKey:@"user_Email"];
                [self.arrUser addObject:self.dicUser];
            }
            [self.tblUser reloadData];
        }
    }
    [self.tblUser reloadData];
}

- (IBAction)InsertClick:(UIButton *)sender {
    if (![_txtName.text  isEqual: @""] && ![_txtCity.text  isEqual: @""] && ![_txtEmail.text isEqual:@""]) {
        NSManagedObject *insert = [NSEntityDescription insertNewObjectForEntityForName:@"User" inManagedObjectContext:self.contex];
        [insert setValue:_txtName.text forKey:@"user_Name"];
        [insert setValue:_txtCity.text forKey:@"user_City"];
        [insert setValue:_txtEmail.text forKey:@"user_Email"];
        NSError *error;
        [self.contex save:&error];
        _txtName.text = @"";
        _txtCity.text = @"";
        _txtEmail.text = @"";
        [self FetchAllRecord];
    }
}

- (IBAction)UpdateClick:(UIButton *)sender {
    NSFetchRequest *request = [NSFetchRequest fetchRequestWithEntityName:@"User"];
    NSEntityDescription *entityDesc = [NSEntityDescription entityForName:@"User" inManagedObjectContext:self.contex];
    request.entity = entityDesc;
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"user_Email like %@",_txtEmail.text];
    request.predicate = predicate;
    
    NSArray *fetchedObjects;
    NSError *error;
    fetchedObjects = [self.contex executeFetchRequest:request error:&error];
    
    if (error != nil) {
        NSLog(@"%@",error);
    } else {
        if (fetchedObjects.count > 0) {
            NSManagedObject *result = fetchedObjects[0];
            [result setValue:_txtName.text forKey:@"user_Name"];
            [result setValue:_txtCity.text forKey:@"user_City"];
            [result setValue:_txtEmail.text forKey:@"user_Email"];
            [self.contex save:&error];
            _txtName.text = @"";
            _txtCity.text = @"";
            _txtEmail.text = @"";
            [self FetchAllRecord];
        }
    }
}

- (IBAction)DeleteClick:(UIButton *)sender {
    NSFetchRequest *request = [NSFetchRequest fetchRequestWithEntityName:@"User"];
    NSEntityDescription *entityDesc = [NSEntityDescription entityForName:@"User" inManagedObjectContext:self.contex];
    request.entity = entityDesc;
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"user_Email like %@",_txtEmail.text];
    request.predicate = predicate;
    
    NSArray *fetchedObjects;
    NSError *error;
    fetchedObjects = [self.contex executeFetchRequest:request error:&error];

    if (error != nil) {
        NSLog(@"%@",error);
    } else {
        if (fetchedObjects.count > 0) {
            NSManagedObject *result = fetchedObjects[0];
            [[self contex] deleteObject:result];
            [self.contex save:&error];
            _txtEmail.text = @"";
            [self FetchAllRecord];
        }
    }
}

- (IBAction)SelectClick:(UIButton *)sender {
    NSFetchRequest *request = [NSFetchRequest fetchRequestWithEntityName:@"User"];
    NSEntityDescription *entityDesc = [NSEntityDescription entityForName:@"User" inManagedObjectContext:self.contex];
    request.entity = entityDesc;
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"user_Email like %@",_txtEmail.text];
    request.predicate = predicate;
    
    NSArray *fetchedObjects;
    NSError *error;
    fetchedObjects = [self.contex executeFetchRequest:request error:&error];
    NSLog(@"%@",fetchedObjects);
    if (error == nil) {
        if (fetchedObjects.count > 0) {
            NSManagedObject *result = fetchedObjects[0];
            NSLog(@"%@",[result valueForKey:@"user_Name"]);
            NSLog(@"%@",[result valueForKey:@"user_Email"]);
            NSLog(@"%@",[result valueForKey:@"user_City"]);
        }
    } else {
        NSLog(@"%@",error);
    }
}

#pragma mark - TableView Delegate & Datasource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [self.arrUser count];
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UserTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell" forIndexPath:indexPath];
    NSMutableDictionary *dicUserData = self.arrUser[indexPath.row];
    cell.lblName.text = [dicUserData valueForKey:@"user_Name"];
    cell.lblCity.text = [dicUserData valueForKey:@"user_City"];
    cell.lblEmail.text = [dicUserData valueForKey:@"user_Email"];
    return cell;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
