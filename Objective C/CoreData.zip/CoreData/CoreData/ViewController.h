//
//  ViewController.h
//  CoreData
//
//  Created by EbitNHP-i1 on 10/09/18.
//  Copyright © 2018 EbitNHP-i1. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

