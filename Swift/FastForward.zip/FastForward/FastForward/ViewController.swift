//
//  ViewController.swift
//  FastForward
//
//  Created by EbitNHP-i1 on 08/08/18.
//  Copyright © 2018 EbitNHP-i1. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var animationView: UIView!
    var arrItem = ["One","Two","Three","Four","Five","Six"]
    var row = 0
    var timer = Timer()
    var winTimer = Timer()
    var arrTemp = [Any]()
    override func viewDidLoad() {
        super.viewDidLoad()
        //Array
        for _ in 0..<600
        {
            for j in 0..<arrItem.count
            {
              arrTemp.append(arrItem[j])
            }
        }
        //View Animation in CollectionView
        viewConfigrations()
        
        //Scrolling Timer
        timer = Timer.scheduledTimer(timeInterval: 0.2, target: self, selector: #selector(autoScroll), userInfo: nil, repeats: true)
    }
    //Timer method
    @objc func autoScroll()
    {
        collectionView.scrollToItem(at: IndexPath(row: row, section: 0), at: .centeredHorizontally, animated: true)
        row += 1
    }
    @objc func presentWinner()
    {
        var centerCellIndexPath: IndexPath? = collectionView?.indexPathForItem(at: view.convert(view.center, to: collectionView))
        
        let strWinName = arrTemp[(centerCellIndexPath?.row)!]
        let alert = UIAlertController(title: strWinName as? String, message: "Winner", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
        //present(alert, animated: true, completion: nil)
        print("Winner Name: ",strWinName)
        winTimer.invalidate()
        animationView.isHidden = false
        
        //View Animation
        UIView.animate(withDuration: 2.0) {
            self.animationView.frame = CGRect(x: 0, y: 318, width: UIScreen.main.bounds.size.width, height: 100)
        }
    }
    
    func updateCellsLayout()  {
        let centerX = collectionView.contentOffset.x + (collectionView.frame.size.width)/2
        
        for cell in collectionView.visibleCells {
            var offsetX = centerX - cell.center.x
            if offsetX < 0 {
                offsetX *= -1
            }
            cell.transform = CGAffineTransform.identity
            let offsetPercentage = offsetX / (view.bounds.width * 2.7)
            let scaleX = 1-offsetPercentage
            cell.transform = CGAffineTransform(scaleX: scaleX, y: scaleX)
        }
    }
    //Register Nib
    private func viewConfigrations() {
        collectionView.register(UINib(nibName: "PlayerCell", bundle: nil), forCellWithReuseIdentifier: "PlayerCell")
        collectionView.contentInset = UIEdgeInsetsMake(0, 5, 0, 5)
    }
    
    @IBAction func btnPlay(_ sender: UIButton) {
        timer.invalidate()
        winTimer = Timer.scheduledTimer(timeInterval: 0.3, target: self, selector: #selector(presentWinner), userInfo: nil, repeats: true)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

//MARK:- Collectionview Delegate
extension ViewController: UICollectionViewDataSource,UICollectionViewDelegateFlowLayout,UICollectionViewDelegate
{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return arrTemp.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell{
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "PlayerCell", for: indexPath) as! PlayerCell
        cell.lblPlayer.text = arrTemp[indexPath.row] as? String
        return cell
    }
    //CollectionView Layout
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let width = collectionView.frame.width
        return CGSize(width: width/2.3-1, height: 100)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat{
        return 5.0
    }
    //ScrollView Method
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        updateCellsLayout()
    }
    
    func scrollViewDidEndScrollingAnimation(_ scrollView: UIScrollView) {
        updateCellsLayout()
    }
}
