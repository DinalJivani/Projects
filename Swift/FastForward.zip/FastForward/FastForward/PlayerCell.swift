//
//  PlayerCell.swift
//  FastForward
//
//  Created by EbitNHP-i1 on 08/08/18.
//  Copyright © 2018 EbitNHP-i1. All rights reserved.
//

import UIKit

class PlayerCell: UICollectionViewCell {
    @IBOutlet weak var playerView: UIView!
    @IBOutlet weak var lblPlayer: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
