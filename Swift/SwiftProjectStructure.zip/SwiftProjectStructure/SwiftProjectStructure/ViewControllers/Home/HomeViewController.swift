//
//  HomeViewController.swift
//  SwiftProjectStructure
//
//  Created by Krishna Patel on 18/06/18.
//  Copyright © 2018 Krishna. All rights reserved.
//

import UIKit

class HomeViewController: UIViewController, ServiceManagerDelegate, UITableViewDataSource, UITableViewDelegate {
    
    @IBOutlet weak var tblView: UITableView!
    
    let utils = Utils()
    let serviceMgr = ServiceManager()
    var arrDietData : [[String : Any]] = []
    var isFirst : Bool = true
    var pageToken : Int = 0
    var footerview = UIView()
    var blankfooterview = UIView()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        initialize()
        setUpLayout()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    //MARK: - INITIALIZATION
    func initialize() {
        serviceMgr.delegate = self
    //    NotificationCenter.default.addObserver(self, selector: #selector(AppDelegate.rotated), name: NSNotification.Name.UIDeviceOrientationDidChange, object: nil)
    }
    
    //MARK: - SETUP LAYOUT
    func setUpLayout() {
        self.view.backgroundColor = utils.getThemeColor()
        GetLifeStyle()
        tblView.register(UINib.init(nibName: "HomeCustomCell", bundle: Bundle.main), forCellReuseIdentifier: "Cell")
        self.navigationController?.isNavigationBarHidden = true
        self.navigationController?.setNavigationBarHidden(true, animated: false)
        self.navigationController?.interactivePopGestureRecognizer?.isEnabled = true
        
        self.view.gradientBackground(ColorSet: [UIColor(hexString: "fc1bab"), UIColor(hexString: "fc0e23")], direction: .topToBottom)
        
        footerview = utils.createFooterView()!
        blankfooterview = utils.createBlankFooterView()!
        
       /*
        let aModel = AttachmentViewModel()
        aModel.Image = UIImage(named:  "aa.jpg")!
        aModel.ImageFileName = "attachment"
        
        var arrAttachemnt : [AttachmentViewModel] = []
        arrAttachemnt.append(aModel)
        
        print(arrAttachemnt)

        let m = arrAttachemnt[0]
        print("\(m.ImageFileName)") */
        
    }
    
    //MARK: - BUTTONS
    @IBAction func btnMenuClicked(_ sender: Any) {
        self.slideMenuController()?.openLeft()
    }
    
    //MARK: - UITABLEVIEW METHODS
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrDietData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell") as! HomeCustomCell
        let d : [String : Any] = arrDietData[indexPath.row]
        cell.lblTitle.text = d["Question"] as? String
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 32
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
       // doLogin()
       /* let view = storyboard?.instantiateViewController(withIdentifier: "CommonViewController") as! CommonViewController
        PUSH(v: view)*/
    }
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        if indexPath.row == arrDietData.count - 1 && pageToken != -1 {
            isFirst = false
            tblView.tableFooterView = footerview
            ((footerview.viewWithTag(10)) as! UIActivityIndicatorView).startAnimating()
            GetLifeStyle()
        }
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        if pageToken == -1 {
            return 0.0
        }else {
            return 30.0
        }
    }
    
    //MARK: - SERVICE MANAGER METHODS
    func webServiceCallSuccess(_ response: Any?, forTag tagname: String?) {
        if(tagname == "ABC"){
            parseGetUserData(response: response)
        }else if(tagname == "login"){
            parseLoginData(response: response)
        }
    }
    func webServiceCallFailure(_ error: Error?, forTag tagname: String?) {
        utils.dismissHUD(fromView: self.view)
        print(kPROBLEM_FROM_SERVER)
    }
    
    func GetLifeStyle() {
        if(utils.connected()){
            if(isFirst) { utils.ShowHUD(inView: self.view) }
            
            let param = [
                "UsersID" : "60",
                "ques" : "all",
                "page_token" : String(pageToken)
                ]
            
            let webpath = "\(cWEBHOST)\(cGET_ALL_QUESTION)"
            serviceMgr.callWebServiceWithPOST(webpath: webpath, withTag: "ABC", params: param)
        }else{
            print(kCHECK_INTERNET_CONNECTION)
        }
    }
    
    func parseGetUserData(response : Any?)  {
        if(response != nil){
            let dicResponse = response as! NSDictionary
            print(dicResponse)
            if (dicResponse.value(forKey: "status") != nil) == true{
                pageToken = dicResponse.value(forKey: "page_token") as Any as! Int
                let arrData = dicResponse.value(forKey: "data") as! NSArray
                
                for i in 0..<arrData.count {
                    arrDietData.append(arrData.object(at: i) as! [String : Any])
                }
              
                print(arrDietData)
               tblView.reloadData()
            }else{
                print(dicResponse.value(forKey: "message") ?? "")
            }
        }
        utils.dismissHUD(fromView: self.view)
    }
    
    func doLogin() {
        if(utils.connected()){
            utils.ShowHUD(inView: self.view)
            let param = [
                "email" : "bb@gmail.com",
                "password" : "123456",
                "device_type" : "1",
                "device_token" : "1",
                ]
            let webpath = "\(cWEBHOST)\(cLOGIN)"
            serviceMgr.callWebServiceWithPOST(webpath: webpath, withTag: "login", params: param)
        }else{
            print(kCHECK_INTERNET_CONNECTION)
        }
    }
    
    func parseLoginData(response : Any?)  {
        if(response != nil){
            let dicResponse = response as! NSDictionary
            print(dicResponse)
            if (dicResponse.value(forKey: "status") != nil) == true{
                print("Login Successfully done")
            }else{
                print(dicResponse.value(forKey: "message") ?? "")
            }
        }
        utils.dismissHUD(fromView: self.view)
    }
    
    
   
}
