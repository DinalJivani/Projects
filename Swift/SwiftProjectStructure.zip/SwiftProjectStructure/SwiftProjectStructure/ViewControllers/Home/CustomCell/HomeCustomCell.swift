//
//  HomeCustomCell.swift
//  SwiftProjectStructure
//
//  Created by Krishna Patel on 20/06/18.
//  Copyright © 2018 Krishna. All rights reserved.
//

import UIKit

class HomeCustomCell: UITableViewCell {

    @IBOutlet weak var lblTitle: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
