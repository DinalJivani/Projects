//
//  LeftMenuViewController.swift
//  SwiftProjectStructure
//
//  Created by Krishna Patel on 21/06/18.
//  Copyright © 2018 Krishna. All rights reserved.
//

import UIKit

class LeftMenuViewController: UIViewController,  UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var tblMenu: UITableView!
    
    var arrMenu : [MenuViewModel] = []
    var utils = Utils()
    var mainViewController: UIViewController!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        initialize()
        setUpLayout()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
       /* for i in 0..<arrMenu.count {
            let indexpath = IndexPath(row: i, section: 0)
            tblMenu.reloadRows(at: [indexpath], with: .right)
        }*/
       // tblMenu.reloadData()
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    // MARK: - INITIALIZATION
    func initialize() {
    }
    
    // MARK: - SETUP LAYOUT
    func setUpLayout() {
        createMenuData()
        tblMenu.reloadData()
    }
    
    func createMenuData() {
        let m1 = MenuViewModel()
        m1.MenuIcon = UIImage(named:  "aa.jpg")!
        m1.MenuName = "Home"
        m1.MenuController = (self.storyboard?.instantiateViewController(withIdentifier: "HomeViewController"))!
        arrMenu.append(m1);
        
        let m2 = MenuViewModel()
        m2.MenuIcon = UIImage(named:  "aa.jpg")!
        m2.MenuName = "Contact Us"
        m2.MenuController = (self.storyboard?.instantiateViewController(withIdentifier: "CommonViewController"))!
        arrMenu.append(m2);

        let m3 = MenuViewModel()
        m3.MenuIcon = UIImage(named:  "aa.jpg")!
        m3.MenuName = "About Us"
        m3.MenuController = (self.storyboard?.instantiateViewController(withIdentifier: "CommonViewController"))!
        arrMenu.append(m3);
        
        let m4 = MenuViewModel()
        m4.MenuIcon = UIImage(named:  "aa.jpg")!
        m4.MenuName = "Logout"
        m4.MenuController = (self.storyboard?.instantiateViewController(withIdentifier: "LoginViewController"))!
        arrMenu.append(m4);
    }
    // MARK: - BUTTONS
    
    // MARK: - UITABLEVIEW METHODS
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrMenu.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MenuCell", for: indexPath) as! MenuCustomCell
        utils.makeCircular(view: cell.imgMenu)
        let model = arrMenu[indexPath.row];
        cell.lblMenuName.text = model.MenuName as String
        cell.imgMenu.image = model.MenuIcon
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
         let model = arrMenu[indexPath.row];
        if(indexPath.row == arrMenu.count - 1){
            utils.doLogOut()
            let nav = UINavigationController(rootViewController: model.MenuController)
            nav.isNavigationBarHidden = true
            self.slideMenuController()?.removeLeftGestures()
            self.slideMenuController()?.changeMainViewController(nav, close: true)
        }else{
            self.slideMenuController()?.changeMainViewController(model.MenuController, close: true)
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 45;
    }
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
       cell.alpha = 0.0
        let transform =  CATransform3DTranslate(CATransform3DIdentity, -250, 20, 0)
        cell.layer.transform = transform
        
        UIView.animate(withDuration: 1.0) {
            cell.alpha = 1.0
            cell.layer.transform = CATransform3DIdentity
        }
    }
}
