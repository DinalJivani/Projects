//
//  MenuViewModel.swift
//  SwiftProjectStructure
//
//  Created by Krishna Patel on 21/06/18.
//  Copyright © 2018 Krishna. All rights reserved.
//

import Foundation
import UIKit

class MenuViewModel: NSObject {
    
    var MenuName = ""
    var MenuIcon = UIImage()
    var MenuController = UIViewController() 
}
