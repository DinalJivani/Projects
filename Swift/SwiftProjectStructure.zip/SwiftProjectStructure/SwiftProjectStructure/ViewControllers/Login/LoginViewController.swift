//
//  LoginViewController.swift
//  SwiftProjectStructure
//
//  Created by Krishna Patel on 21/06/18.
//  Copyright © 2018 Krishna. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {
    
    var utils = Utils()
    
    @IBOutlet weak var btnLogin: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        initialize()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    // MARK: - INITIALIZATION
    func initialize()  {
        navigationController?.setNavigationBarHidden(false, animated: true)
        navigationController?.interactivePopGestureRecognizer?.isEnabled = false
    }
    
    // MARK: - BUTTONS
    @IBAction func btnLoginClicked(_ sender: Any) {
        self.slideMenuController()?.addLeftGestures()
        let view = storyboard?.instantiateViewController(withIdentifier: "HomeViewController") as! HomeViewController
       // navigationController?.pushViewController(view, animated: true)
        self.slideMenuController()?.changeMainViewController(view, close: true)
        utils.setIsUserLoggegIn(status: true)
        
    }

}
