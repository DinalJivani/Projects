//
//  CommonViewController.swift
//  SwiftProjectStructure
//
//  Created by Krishna Patel on 21/06/18.
//  Copyright © 2018 Krishna. All rights reserved.
//

import UIKit

class CommonViewController: UIViewController {

    @IBOutlet weak var viewMainContainer: UIView!
    @IBOutlet weak var viewPlay: UIView!
    @IBOutlet weak var lbl1: UILabel!
    @IBOutlet weak var lbl2: UILabel!
    @IBOutlet weak var lbl3: UILabel!
    @IBOutlet weak var imgView: UIImageView!
    
    var mainContainerOriginalFrame : CGRect!
    var mainContainerModifiedFrame : CGRect!
    var viewPlayOrifinalFrame : CGRect!
    var viewPlayModifiedFrame : CGRect!
    var lbl1OriginalFrame : CGRect!
    var lbl1ModifiedFrame : CGRect!
    var lbl2OriginalFrame : CGRect!
    var lbl2ModifiedFrame : CGRect!
    var lbl3OriginalFrame : CGRect!
    var lbl3ModifiedFrame : CGRect!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpLayout()
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
   
    func setUpLayout() {
        // self.createGradientLayer()
      
        viewPlay.gradientBackground(ColorSet: [UIColor(hexString: "fc1bab"), UIColor(hexString: "fc0e23"), UIColor(hexString: "000000"), UIColor(hexString: "ffffff")], direction: .TopLeftToBottomRight)
        
        viewPlay.layer.cornerRadius = 9.0
    }
    
   override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
    
    
    }
    
    //MARK: - BUTTONS
    @IBAction func btnMenuClicked(_ sender: Any) {
        self.slideMenuController()?.openLeft()
    }

    @IBAction func btnAnimateClicked(_ sender: Any) {
        doAnimation()
    }
    
    @IBAction func btnMusicClicked(_ sender: Any) {
        let view = storyboard?.instantiateViewController(withIdentifier: "SongListViewController") as! SongListViewController
        PUSH(v: view)
    }
    
    func doAnimation() {
        UIView.animate(withDuration: 0.3, animations: {
            
        }) { (finished) in
            self.viewPlayOrifinalFrame = self.viewPlay.frame
            self.viewPlayModifiedFrame = CGRect(x: self.viewPlayOrifinalFrame.origin.x, y: -400, width: self.viewPlayOrifinalFrame.size.width, height: self.viewPlayOrifinalFrame.size.height)
            
            self.lbl1OriginalFrame = self.lbl1.frame
            self.lbl2OriginalFrame = self.lbl2.frame
            self.lbl3OriginalFrame = self.lbl3.frame
            
            self.lbl1ModifiedFrame = CGRect(x: -700, y: self.lbl1OriginalFrame.origin.y, width: self.lbl1OriginalFrame.size.width, height: self.lbl1OriginalFrame.size.height)
            self.lbl2ModifiedFrame = CGRect(x: 1400, y: self.lbl2OriginalFrame.origin.y, width: self.lbl2OriginalFrame.size.width, height: self.lbl2OriginalFrame.size.height)
            self.lbl3ModifiedFrame = CGRect(x: -700, y: self.lbl3OriginalFrame.origin.y, width: self.lbl3OriginalFrame.size.width, height: self.lbl3OriginalFrame.size.height)
            
            self.viewPlay.frame = self.viewPlayModifiedFrame
            self.lbl1.frame = self.lbl1ModifiedFrame
            self.lbl2.frame = self.lbl2ModifiedFrame
            self.lbl3.frame = self.lbl3ModifiedFrame
            
            self.viewPlay.isHidden = false
            self.lbl1.isHidden = false
            self.lbl2.isHidden = false
            self.lbl3.isHidden = false
            
           
            
            UIView.animate(withDuration: 0.5, animations: {
                self.viewPlay.frame = self.viewPlayOrifinalFrame
                self.lbl1.frame = self.lbl1OriginalFrame
                self.lbl2.frame = self.lbl2OriginalFrame
                self.lbl3.frame = self.lbl3OriginalFrame
            
            }, completion: { (finished) in
                self.pulseAnimation(view: self.lbl3)
                
            })
        }
    }
    
    func pulseAnimation(view : UIView)  {
        view.transform = CGAffineTransform(scaleX: 0.8, y: 0.8)
        UIView.animate(withDuration: 0.7, delay: 0.0, options: .curveEaseOut, animations: {
            view.transform = CGAffineTransform(scaleX: 1.0, y: 1.0)
        }) { (finished) in
            UIView.animate(withDuration: 0.7, delay: 0.0, options: .curveEaseOut, animations: {
                view.transform = CGAffineTransform(scaleX: 0.8, y: 0.8)
            }) { (finished) in
                self.pulseAnimation(view: view)
            }
        }
    }
    
    func createGradientLayer() {
        let gradientLayer = CAGradientLayer()
        gradientLayer.frame = self.viewPlay.bounds
        gradientLayer.colors = [UIColor(hexString: "fc1bab").cgColor, UIColor(hexString: "fc0e23").cgColor]
        self.viewPlay.layer.insertSublayer(gradientLayer, at: 0)
        self.viewPlay.clipsToBounds = true
    }


    
}
