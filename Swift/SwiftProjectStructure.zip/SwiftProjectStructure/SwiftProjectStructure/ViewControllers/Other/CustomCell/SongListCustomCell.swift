//
//  SongListCustomCell.swift
//  SwiftProjectStructure
//
//  Created by EbitM02 on 13/07/18.
//  Copyright © 2018 Krishna. All rights reserved.
//

import UIKit

class SongListCustomCell: UITableViewCell {

    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var imgSongThumb: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
