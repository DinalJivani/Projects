//
//  SongListViewController.swift
//  SwiftProjectStructure
//
//  Created by EbitM02 on 13/07/18.
//  Copyright © 2018 Krishna. All rights reserved.
//

import UIKit

class SongListViewController: UIViewController , UITableViewDataSource, UITableViewDelegate{

    @IBOutlet weak var viewTop: UIView!
    @IBOutlet weak var tblView: UITableView!
    var utils = Utils()
    var arrSongList : [SongListViewModel] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        initialize()
        setUpLayout()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        viewTop.gradientBackground(ColorSet: [UIColor(hexString: "fc1bab"), UIColor(hexString: "fc0e23"),], direction: .topToBottom)
    }
    //MARK:- Initializations
    func initialize()  {
        
    }
    //MARK:- SetUpLayout
    func setUpLayout() {
        
        createTableData()
        tblView.reloadData()
    }
    
    func createTableData()  {
        let M1 : SongListViewModel = SongListViewModel ()
        M1.Name = "Saajan"
        M1.SongImage = UIImage(named: "imgDisk1")!
        arrSongList.append(M1)
        
        let M2 : SongListViewModel = SongListViewModel ()
        M2.Name = "Sanju"
        M2.SongImage = UIImage(named: "imgDisk2")!
        arrSongList.append(M2)
        
        let M3 : SongListViewModel = SongListViewModel ()
        M3.Name = "Rocky"
        M3.SongImage = UIImage(named: "imgDisk3")!
        arrSongList.append(M3)
        
        let M4 : SongListViewModel = SongListViewModel ()
        M4.Name = "Munnabhai MBBS"
        M4.SongImage = UIImage(named: "imgDisk4")!
        arrSongList.append(M4)
    }
    
    // MARK: - UITABLEVIEW METHODS
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrSongList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CustomCell", for: indexPath) as! SongListCustomCell
        utils.makeCircular(view: cell.imgSongThumb)
        let model = arrSongList[indexPath.row];
        cell.lblName.text = model.Name as String
        cell.imgSongThumb.image = model.SongImage
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let model = arrSongList[indexPath.row];
    }
    
}
