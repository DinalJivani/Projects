//
//  SongListViewModel.swift
//  SwiftProjectStructure
//
//  Created by EbitM02 on 13/07/18.
//  Copyright © 2018 Krishna. All rights reserved.
//

import Foundation
import UIKit

class SongListViewModel: NSObject {
    var Name = ""
    var SongImage = UIImage()
}
