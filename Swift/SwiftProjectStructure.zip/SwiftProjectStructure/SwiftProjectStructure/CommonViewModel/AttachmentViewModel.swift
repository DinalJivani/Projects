//
//  AttachmentViewModel.swift
//  SwiftProjectStructure
//
//  Created by Krishna Patel on 20/06/18.
//  Copyright © 2018 Krishna. All rights reserved.
//

import UIKit

class AttachmentViewModel: NSObject {

    var Image = UIImage()
    var ImageFileName = ""
    
}
