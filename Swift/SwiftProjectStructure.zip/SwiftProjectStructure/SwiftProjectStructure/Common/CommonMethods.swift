//
//  CommonMethods.swift
//  SwiftProjectStructure
//
//  Created by Krishna Patel on 29/06/18.
//  Copyright © 2018 Krishna. All rights reserved.
//

import Foundation
import UIKit

func PUSH(v: UIViewController)  {
    APPDELEGATE?.navigation.pushViewController(v, animated: true)
}

func POP() {
    APPDELEGATE?.navigation.popViewController(animated: true)
}

func PRESENT_VC(v : UIViewController) {
    APPDELEGATE?.navigation .present(v, animated: true, completion: nil)
}

func DISMISS_VC() {
    APPDELEGATE?.navigation.dismiss(animated: true, completion: nil)
}


