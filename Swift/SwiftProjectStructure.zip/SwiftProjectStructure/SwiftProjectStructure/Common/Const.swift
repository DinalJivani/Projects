//
//  Const.swift
//  SwiftProjectStructure
//
//  Created by Krishna Patel on 18/06/18.
//  Copyright © 2018 Krishna. All rights reserved.
//

import Foundation
import UIKit

//MARK: - CHECK FOR DEVICE
let IS_IPHONE4 = (UIScreen.main.bounds.size.height - 480) != 0.0 ? false : true
let IS_IPAD = UI_USER_INTERFACE_IDIOM() != .phone
let IS_IPHONE5s = UIScreen.main.bounds.size.height <= 568 ? true : false
let IS_IPHONEX = UIScreen.main.bounds.size.height == 812 ? true : false

//MARK: - SCREEN BOUNDS
let SCREEN_WIDTH = UIScreen.main.bounds.size.width
let SCREEN_HEIGHT = UIScreen.main.bounds.size.height

//MARK: - GET APPDELEGATE
let APPDELEGATE = UIApplication.shared.delegate as? AppDelegate

//MARK: - API HOST URL
let cWEBHOST = "https://www.lookforsuccess.net/APIs/"

//MARK: - API NAMES
let cLOGIN  = "login.php"
let cSIGNUP = "signup.php"
let cGET_LIFE_STYLE = "get_life_style.php"
let cGET_ALL_QUESTION = "question_list.php"

//MARK: - NOTIFICATION NAMES
let nNOTIFICATION_LOGOUT   =    "logoutNotification"

//MARK: - SOME COMMON THINGS
let kCHECK_INTERNET_CONNECTION   =  "Check your internet connection"
let kPROBLEM_FROM_SERVER         =  "Problem Receiving Data From Server"

//MARK: - SOME ACCOUNT KEYS, e.g google, gmail, paypal, facebook, twitter

//MARK: - iTUNES URL for Share App
let iTunesURL = ""
let APPSTORE_APPID  = ""

//MARK: - FONT NAMES
let fFONT_REGULAR   =   "HelveticaNeue"
let fFONT_BOLD      =   "HelveticaNeue-Bold"
let fFONT_MEDIUM    =   "HelveticaNeue-Medium"

//MARK: - USER TYPE IF MORE USER

//MARK: - USERDEFAULT RELATED
let sIS_USER_LOGGEDIN   = "IsUserLoggedIn"
let sFCM_TOKEN          = "FCM_TOKEN"

//MARK: - SET APP THEME COLOR
let THEME_COLOR        = "3C69B2"


