//
//  MarkerView.swift
//  Rome2Rio
//
//  Created by EbitNHP-i1 on 09/08/18.
//  Copyright © 2018 EbitNHP-i1. All rights reserved.
//

import UIKit

class MarkerView: UIView {
    @IBOutlet weak var imgMarker: UIImageView!
    @IBOutlet weak var lblRouteName: UILabel!
    @IBOutlet var contentView: UIView!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        commonInit()
        fatalError("init(coder:) has not been implemented")
    }
    private func commonInit()
    {
        Bundle.main.loadNibNamed("MarkerView", owner: self, options: nil)
        addSubview(contentView)
        lblRouteName.autoresizingMask = [.flexibleHeight,.flexibleWidth]
        lblRouteName.layer.cornerRadius = 10
        //contentView.frame = self.bounds
        contentView.autoresizingMask = [.flexibleWidth,.flexibleHeight]
    }

}
