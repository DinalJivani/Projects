//
//  HeaderTableViewCell.swift
//  Rome2Rio
//
//  Created by EbitNHP-i1 on 25/09/18.
//  Copyright © 2018 EbitNHP-i1. All rights reserved.
//

import UIKit

class HeaderTableViewCell: UITableViewCell {
    @IBOutlet weak var lblTime: UILabel!
    @IBOutlet weak var lblRouteName: UILabel!
    @IBOutlet weak var lblApproxPrice: UILabel!
    @IBOutlet weak var btnPlan: UIButton!
    @IBOutlet weak var btnShowHide: UIButton!
    @IBOutlet weak var btnDrawRoute: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
