//
//  DetailTableViewCell.swift
//  Rome2Rio
//
//  Created by EbitNHP-i1 on 20/09/18.
//  Copyright © 2018 EbitNHP-i1. All rights reserved.
//

import UIKit

class DetailTableViewCell: UITableViewCell {
    @IBOutlet weak var imgVehicle: UIImageView!
    @IBOutlet weak var lblSource: UILabel!
    @IBOutlet weak var vwRoute: UIView!
    @IBOutlet weak var lblDestination: UILabel!
    @IBOutlet weak var lblDuration: UILabel!
    @IBOutlet weak var lblLineCode: UILabel!
    @IBOutlet weak var lblApproxPrice: UILabel!
    @IBOutlet weak var vwSource: UIView!
    @IBOutlet weak var vwDestination: UIView!
    @IBOutlet weak var stkDotLine: UIStackView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
