//
//  DetailViewController.swift
//  Rome2Rio
//
//  Created by EbitNHP-i1 on 20/09/18.
//  Copyright © 2018 EbitNHP-i1. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {
    @IBOutlet weak var tblDetail: UITableView!
    var dicData = NSMutableDictionary()
    var arrSegment = NSArray()
    var dicSelectedSag = NSDictionary()
    var dicRoutes = NSDictionary()
    var flCellHeight = CGFloat()
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tblDetail.estimatedRowHeight = 63.0
        self.tblDetail.rowHeight = UITableViewAutomaticDimension
        self.tblDetail.tableFooterView = UIView()
        
        print(dicSelectedSag)
        
        //Register Cell
        let nibDetail = UINib(nibName: "DetailTableViewCell", bundle: nil)
        self.tblDetail.register(nibDetail, forCellReuseIdentifier: "detailCell")
        
        let nibRouteDetail = UINib(nibName: "RouteDetailTableViewCell", bundle: nil)
        self.tblDetail.register(nibRouteDetail, forCellReuseIdentifier: "routeDetailCell")
        
        let nibWalk = UINib(nibName: "WalkTableViewCell", bundle: nil)
        self.tblDetail.register(nibWalk, forCellReuseIdentifier: "walkCell")
        
        // Do any additional setup after loading the view.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if arrSegment.count > 0 {
            return 2 //arrSegment.count + 1
        } else {
            return 0
        }
    }
    

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var dicSegment = NSDictionary()
        var dicVehicle = NSDictionary()
        var strVehicleType = String()
        let arrVehicle = dicData.value(forKey: "vehicles") as! NSArray
        
        if indexPath.row > 0 {
//            dicSegment = arrSegment[indexPath.row - 1] as! NSDictionary
            dicSegment = dicSelectedSag
        }
        
        let intVehicle = dicSegment.value(forKey: "vehicle") as? Int
        if intVehicle != nil {
            dicVehicle = arrVehicle[intVehicle!] as! NSDictionary
            strVehicleType = dicVehicle.value(forKey: "name") as! String
        }
        
        if indexPath.row == 0 {
            
            let routeDetailCell = tableView.dequeueReusableCell(withIdentifier: "routeDetailCell", for: indexPath) as! RouteDetailTableViewCell
            
            //Counting Transit Time duration
            let interval = dicRoutes.value(forKey: "totalDuration") as? Int
            let formatter = DateComponentsFormatter()
            formatter.allowedUnits = [.hour, .minute]
            formatter.unitsStyle = .abbreviated
            let formattedString = formatter.string(from: TimeInterval(interval! * 60))!
            
            //Couting Transfer Duration
            let intDuration = dicRoutes.value(forKey: "totalTransferDuration") as? Int
            let strTranser = formatter.string(from: TimeInterval(intDuration! * 60))
            if intDuration != 0 {
                routeDetailCell.lblDuration.text = "includes \(strTranser ?? "0") transfer"
            } else {
                routeDetailCell.lblDuration.text = ""
            }
            
            //Approx Price
            let arrPrices = dicRoutes.value(forKey: "indicativePrices") as! NSArray
            let arrPriceLow = arrPrices.value(forKey: "priceLow") as! NSArray
            let arrPriceHigh = arrPrices.value(forKey: "priceHigh") as! NSArray

            if "\(arrPriceLow[0])" == "<null>" {
                let dicPriceLow = arrPrices[0] as! NSDictionary
                let dicPriceHigh = arrPrices[2] as! NSDictionary
                let intPriceLow = dicPriceLow.value(forKey: "price") as! Int
                let intPriceHigh = dicPriceHigh.value(forKey: "price") as! Int
                routeDetailCell.lblApproxPrice.text = "Approx Price: " + "₹ " + "\(intPriceLow)" + " - " + "₹ " + "\(intPriceHigh)"
            } else {
                routeDetailCell.lblApproxPrice.text = "Approx Price: " + "₹ " + "\(arrPriceLow[0])" + " - " + "₹ " + "\(arrPriceHigh[0])"
            }
            routeDetailCell.lblRouteName.text = dicRoutes.value(forKey: "name") as? String
            routeDetailCell.lblTime.text = formattedString
            flCellHeight = 146
            return routeDetailCell
        } else if strVehicleType != "Walk" {
            let detailCell = tableView.dequeueReusableCell(withIdentifier: "detailCell", for: indexPath) as! DetailTableViewCell
            
//            let dicSegment = arrSegment[indexPath.row - 1] as! NSDictionary
            
            if (dicSegment.value(forKey: "agencies") as? NSArray) != nil {
                let arrAgencies = dicSegment.value(forKey: "agencies") as! NSArray
                print(arrAgencies)
            } else {
                print("Null")
            }
            
            //Counting Time Duration
            let interval = dicSegment.value(forKey: "transitDuration") as? Int
            let formatter = DateComponentsFormatter()
            formatter.allowedUnits = [.hour, .minute]
            formatter.unitsStyle = .abbreviated
            let formattedString = formatter.string(from: TimeInterval(interval! * 60))!
            detailCell.lblDuration.text = formattedString
            
            // Counting Approx Price
            if (dicSegment.value(forKey: "indicativePrices") as? NSArray) != nil {
                let arrPrice = dicSegment.value(forKey: "indicativePrices") as! NSArray
                let arrPriceLow = arrPrice.value(forKey: "priceLow") as! NSArray
                let arrPriceHigh = arrPrice.value(forKey: "priceHigh") as! NSArray
                if "\(arrPriceLow[0])" == "<null>" {
                    if arrPrice[0] as? NSDictionary != nil {
                        if arrPrice.count > 1 {
                            let dicPriceLow = arrPrice[0] as! NSDictionary
                            let dicPriceHigh = arrPrice[2] as! NSDictionary
                            let intPriceLow = dicPriceLow.value(forKey: "price") as! Int
                            let intPriceHigh = dicPriceHigh.value(forKey: "price") as! Int
                            detailCell.lblApproxPrice.text = "₹ " + "\(intPriceLow)" + " - " + "₹ " + "\(intPriceHigh)"
                        } else {
                            let dicPrice = arrPrice[0] as! NSDictionary
                            detailCell.lblApproxPrice.text = "₹ " + "\(dicPrice.value(forKey: "price") as!Int)" 
                        }
                        
                    } else {
                        detailCell.lblApproxPrice.text = ""
                    }
                    
                    
                } else {
                    detailCell.lblApproxPrice.text = "₹ " + "\(arrPriceLow[0])" + " - " + "₹ " + "\(arrPriceHigh[0])"
                }
            }
            
            // Sorce And Destination
            let intDepPlace = dicSegment.value(forKey: "depPlace") as? Int
            let intArrPlace = dicSegment.value(forKey: "arrPlace") as? Int
            let arrPlaces = dicData.value(forKey: "places") as! NSArray
            let dicArrPlace = arrPlaces[intArrPlace!] as! NSDictionary
            let dicDepPlace = arrPlaces[intDepPlace!] as! NSDictionary
            
            if dicDepPlace.value(forKey: "code") != nil {
                let strShortName = dicDepPlace.value(forKey: "shortName") as? String
                if (strShortName?.contains("("))! {
                    detailCell.lblSource.text = dicDepPlace.value(forKey: "shortName") as? String
                } else {
                    detailCell.lblSource.text = strShortName!+"(\(dicDepPlace.value(forKey: "code") ?? ""))"
                }
            } else {
                detailCell.lblSource.text = dicDepPlace.value(forKey: "shortName") as? String
            }
            
            if dicArrPlace.value(forKey: "code") != nil {
                let strShortName = dicArrPlace.value(forKey: "shortName") as? String
                if (strShortName?.contains("("))! {
                    detailCell.lblDestination.text = dicArrPlace.value(forKey: "shortName") as? String
                } else {
                    detailCell.lblDestination.text = strShortName!+"(\(dicArrPlace.value(forKey: "code") ?? ""))"
                }
                
            } else {
                detailCell.lblDestination.text = dicArrPlace.value(forKey: "shortName") as? String
            }
            
            //Change View Color
            let arrVehicle = dicData.value(forKey: "vehicles") as! NSArray
            let intVehicle = dicSegment.value(forKey: "vehicle") as? Int
            let dicVehicle = arrVehicle[intVehicle!] as! NSDictionary
            let strVehicleType = dicVehicle.value(forKey: "name") as? String
            detailCell.vwSource.clipsToBounds = true
            detailCell.vwSource.layer.cornerRadius = detailCell.vwSource.bounds.size.width / 2
            detailCell.vwSource.layer.borderWidth = 5.0
            
            detailCell.vwDestination.clipsToBounds = true
            detailCell.vwDestination.layer.cornerRadius = detailCell.vwDestination.bounds.size.width / 2
            detailCell.vwDestination.layer.borderWidth = 5.0
            
            if strVehicleType == "Helicopter"
            {
                detailCell.imgVehicle.image = UIImage(named: "helicopter.png")
                detailCell.vwDestination.layer.borderColor = UIColor(red: 102/255, green: 67/255, blue: 129/255, alpha: 1).cgColor
                detailCell.vwSource.layer.borderColor = UIColor(red: 102/255, green: 67/255, blue: 129/255, alpha: 1).cgColor
                detailCell.vwRoute.backgroundColor = UIColor(red: 102/255, green: 67/255, blue: 129/255, alpha: 1)
            } else if strVehicleType == "Car"
            {
                detailCell.imgVehicle.image = UIImage(named: "car.png")
                detailCell.vwDestination.layer.borderColor = UIColor(red: 85/255, green: 85/255, blue: 85/255, alpha: 1).cgColor
                detailCell.vwSource.layer.borderColor = UIColor(red: 85/255, green: 85/255, blue: 85/255, alpha: 1).cgColor
                detailCell.vwRoute.backgroundColor = UIColor(red: 85/255, green: 85/255, blue: 85/255, alpha: 1)
            } else if strVehicleType == "Bus"
            {
                detailCell.imgVehicle.image = UIImage(named: "bus.png")
                detailCell.vwDestination.layer.borderColor = UIColor(red: 224/255, green: 102/255, blue: 34/255, alpha: 1).cgColor
                detailCell.vwSource.layer.borderColor = UIColor(red: 224/255, green: 102/255, blue: 34/255, alpha: 1).cgColor
                detailCell.vwRoute.backgroundColor = UIColor(red: 224/255, green: 102/255, blue: 34/255, alpha: 1)
            } else if strVehicleType == "Taxi"
            {
                detailCell.imgVehicle.image = UIImage(named: "taxi.png")
                detailCell.vwDestination.layer.borderColor = UIColor(red: 255/255, green: 163/255, blue: 2/255, alpha: 1).cgColor
                detailCell.vwSource.layer.borderColor = UIColor(red: 255/255, green: 163/255, blue: 2/255, alpha: 1).cgColor
                detailCell.vwRoute.backgroundColor = UIColor(red: 255/255, green: 163/255, blue: 2/255, alpha: 1)
            } else if strVehicleType == "Rideshare"
            {
                detailCell.imgVehicle.image = UIImage(named: "rideshare.png")
                detailCell.vwDestination.layer.borderColor = UIColor(red: 121/255, green: 195/255, blue: 66/255, alpha: 1).cgColor
                detailCell.vwSource.layer.borderColor = UIColor(red: 121/255, green: 195/255, blue: 66/255, alpha: 1).cgColor
                detailCell.vwRoute.backgroundColor = UIColor(red: 121/255, green: 195/255, blue: 66/255, alpha: 1)
            } else if strVehicleType == "Shuttle"
            {
                detailCell.imgVehicle.image = UIImage(named: "shuttle.png")
                detailCell.vwDestination.layer.borderColor = UIColor(red: 220/255, green: 1/255, blue: 52/255, alpha: 1).cgColor
                detailCell.vwSource.layer.borderColor = UIColor(red: 220/255, green: 1/255, blue: 52/255, alpha: 1).cgColor
                detailCell.vwRoute.backgroundColor = UIColor(red: 220/255, green: 1/255, blue: 52/255, alpha: 1)
            } else if strVehicleType == "Towncar"
            {
                detailCell.imgVehicle.image = UIImage(named: "towncar.png")
                detailCell.vwDestination.layer.borderColor = UIColor(red: 255/255, green: 163/255, blue: 2/255, alpha: 1).cgColor
                detailCell.vwSource.layer.borderColor = UIColor(red: 255/255, green: 163/255, blue: 2/255, alpha: 1).cgColor
                detailCell.vwRoute.backgroundColor = UIColor(red: 255/255, green: 163/255, blue: 2/255, alpha: 1)
            } else if strVehicleType == "Train"
            {
                detailCell.imgVehicle.image = UIImage(named: "train.png")
                detailCell.vwDestination.layer.borderColor = UIColor(red: 104/255, green: 58/255, blue: 123/255, alpha: 1.0).cgColor
                detailCell.vwSource.layer.borderColor = UIColor(red: 104/255, green: 58/255, blue: 123/255, alpha: 1.0).cgColor
                detailCell.vwRoute.backgroundColor = UIColor(red: 104/255, green: 58/255, blue: 123/255, alpha: 1.0)
            } else if strVehicleType == "Eurotunnel"
            {
                detailCell.imgVehicle.image = UIImage(named: "train.png")
                detailCell.vwDestination.layer.borderColor = UIColor(red: 104/255, green: 58/255, blue: 123/255, alpha: 1.0).cgColor
                detailCell.vwSource.layer.borderColor = UIColor(red: 104/255, green: 58/255, blue: 123/255, alpha: 1.0).cgColor
                detailCell.vwRoute.backgroundColor = UIColor(red: 104/255, green: 58/255, blue: 123/255, alpha: 1.0)
            }
            else if strVehicleType == "Tram"
            {
                detailCell.imgVehicle.image = UIImage(named: "tram.png")
                detailCell.vwDestination.layer.borderColor = UIColor(red: 104/255, green: 58/255, blue: 123/255, alpha: 1.0).cgColor
                detailCell.vwSource.layer.borderColor = UIColor(red: 104/255, green: 58/255, blue: 123/255, alpha: 1.0).cgColor
                detailCell.vwRoute.backgroundColor =  UIColor(red: 104/255, green: 58/255, blue: 123/255, alpha: 1.0)
            } else if strVehicleType == "Cablecar"
            {
                detailCell.imgVehicle.image = UIImage(named: "cablecar.png")
                detailCell.vwDestination.layer.borderColor = UIColor(red: 104/255, green: 58/255, blue: 123/255, alpha: 1.0).cgColor
                detailCell.vwSource.layer.borderColor = UIColor(red: 104/255, green: 58/255, blue: 123/255, alpha: 1.0).cgColor
                detailCell.vwRoute.backgroundColor = UIColor(red: 104/255, green: 58/255, blue: 123/255, alpha: 1.0)
            } else if strVehicleType == "Subway"
            {
                detailCell.imgVehicle.image = UIImage(named: "subway.png")
                detailCell.vwDestination.layer.borderColor = UIColor(red: 104/255, green: 58/255, blue: 123/255, alpha: 1.0).cgColor
                detailCell.vwSource.layer.borderColor = UIColor(red: 104/255, green: 58/255, blue: 123/255, alpha: 1.0).cgColor
                detailCell.vwRoute.backgroundColor = UIColor(red: 104/255, green: 58/255, blue: 123/255, alpha: 1.0)
            } else if strVehicleType == "Tube" {
                detailCell.imgVehicle.image = UIImage(named: "subway.png")
                detailCell.vwDestination.layer.borderColor = UIColor(red: 104/255, green: 58/255, blue: 123/255, alpha: 1.0).cgColor
                detailCell.vwSource.layer.borderColor = UIColor(red: 104/255, green: 58/255, blue: 123/255, alpha: 1.0).cgColor
                detailCell.vwRoute.backgroundColor = UIColor(red: 104/255, green: 58/255, blue: 123/255, alpha: 1.0)
            } else if strVehicleType == "Ferry" {
                detailCell.imgVehicle.image = UIImage(named: "ferry.png")
                detailCell.vwDestination.layer.borderColor = UIColor(red: 99/255, green: 139/255, blue: 241/255, alpha: 1).cgColor
                detailCell.vwSource.layer.borderColor = UIColor(red: 99/255, green: 139/255, blue: 241/255, alpha: 1).cgColor
                detailCell.vwRoute.backgroundColor = UIColor(red: 99/255, green: 139/255, blue: 241/255, alpha: 1)
            } else if strVehicleType == "car ferry" {
                detailCell.imgVehicle.image = UIImage(named: "ferry.png")
                detailCell.vwDestination.layer.borderColor = UIColor(red: 99/255, green: 139/255, blue: 241/255, alpha: 1).cgColor
                detailCell.vwSource.layer.borderColor = UIColor(red: 99/255, green: 139/255, blue: 241/255, alpha: 1).cgColor
                detailCell.vwRoute.backgroundColor = UIColor(red: 99/255, green: 139/255, blue: 241/255, alpha: 1)
            }
            else if strVehicleType == "Animal"
            {
                detailCell.imgVehicle.image = UIImage(named: "animal.png")
                detailCell.vwDestination.layer.borderColor = UIColor.black.cgColor
                detailCell.vwSource.layer.borderColor = UIColor.black.cgColor
                detailCell.vwRoute.backgroundColor = UIColor.black
            } else if strVehicleType == "Bicycle"
            {
                detailCell.imgVehicle.image = UIImage(named: "bicycle.png")
                detailCell.vwDestination.layer.borderColor = UIColor(red: 107/255, green: 186/255, blue: 166/255, alpha: 1.0).cgColor
                detailCell.vwSource.layer.borderColor = UIColor(red: 107/255, green: 186/255, blue: 166/255, alpha: 1.0).cgColor
                detailCell.vwRoute.backgroundColor =  UIColor(red:
                    107/255, green: 186/255, blue: 166/255, alpha: 1.0)
            } else if strVehicleType == "Plane" {
                detailCell.imgVehicle.image = UIImage(named: "FlightMarker.png")
                detailCell.vwDestination.layer.borderColor = UIColor(red: 5/255, green: 194/255, blue: 156/255, alpha: 1.0).cgColor
                detailCell.vwSource.layer.borderColor = UIColor(red: 5/255, green: 194/255, blue: 156/255, alpha: 1.0).cgColor
                detailCell.vwRoute.backgroundColor =  UIColor(red: 5/255, green: 194/255, blue: 156/255, alpha: 1.0)
            } else {
                
            }
            flCellHeight = 175
            return detailCell
        } else {
//            let walkCell = tableView.dequeueReusableCell(withIdentifier: "walkCell", for: indexPath) as! WalkTableViewCell
//            if strVehicleType == "Walk" {
//
//                let radiusFloat = walkCell.vwFirst.bounds.size.width / 2
//                walkCell.vwFirst.clipsToBounds = true
//                walkCell.vwSecond.clipsToBounds = true
//                walkCell.vwThird.clipsToBounds = true
//                walkCell.vwForth.clipsToBounds = true
//                walkCell.vwFirst.layer.cornerRadius = radiusFloat
//                walkCell.vwSecond.layer.cornerRadius = radiusFloat
//                walkCell.vwThird.layer.cornerRadius = radiusFloat
//                walkCell.vwForth.layer.cornerRadius = radiusFloat
//
//                let intDistance = dicSegment.value(forKey: "distance") as? Double
//                let intTime = dicSegment.value(forKey: "transitDuration") as? Int
//                let formatter = DateComponentsFormatter()
//                formatter.allowedUnits = [.hour, .minute]
//                formatter.unitsStyle = .abbreviated
//                let strTime = formatter.string(from: TimeInterval(intTime! * 60))!
//                walkCell.lblTime.text = strTime
//                walkCell.imageView?.image = UIImage(named: "WalkMarker.png")
//                if intDistance! > 1 {
//                    walkCell.lblDistance.text = "Approx \(intDistance ?? 0)" + "km"
//                } else {
//                    walkCell.lblDistance.text = "Approx \(intDistance ?? 0)" + "meters"
//                }
//            }
//            flCellHeight = 63
//            return walkCell
            
            let detailCell = tableView.dequeueReusableCell(withIdentifier: "detailCell", for: indexPath) as! DetailTableViewCell
            
//            let dicSegment = arrSegment[indexPath.row - 1] as! NSDictionary
            
            detailCell.imgVehicle.image = UIImage(named: "WalkMarker.png")
            detailCell.vwRoute.isHidden = true
            detailCell.vwSource.isHidden = true
            detailCell.vwDestination.isHidden = true
            detailCell.stkDotLine.isHidden = false
            
            // Sorce And Destination
            let intDepPlace = dicSegment.value(forKey: "depPlace") as? Int
            let intArrPlace = dicSegment.value(forKey: "arrPlace") as? Int
            let arrPlaces = dicData.value(forKey: "places") as! NSArray
            let dicArrPlace = arrPlaces[intArrPlace!] as! NSDictionary
            let dicDepPlace = arrPlaces[intDepPlace!] as! NSDictionary
            
            if dicDepPlace.value(forKey: "code") != nil {
                let strShortName = dicDepPlace.value(forKey: "shortName") as? String
                if (strShortName?.contains("("))! {
                    detailCell.lblSource.text = dicDepPlace.value(forKey: "shortName") as? String
                } else {
                    detailCell.lblSource.text = strShortName!+"(\(dicDepPlace.value(forKey: "code") ?? ""))"
                }
            } else {
                detailCell.lblSource.text = dicDepPlace.value(forKey: "shortName") as? String
            }
            
            if dicArrPlace.value(forKey: "code") != nil {
                let strShortName = dicArrPlace.value(forKey: "shortName") as? String
                if (strShortName?.contains("("))! {
                    detailCell.lblDestination.text = dicArrPlace.value(forKey: "shortName") as? String
                } else {
                    detailCell.lblDestination.text = strShortName!+"(\(dicArrPlace.value(forKey: "code") ?? ""))"
                }
                
            } else {
                detailCell.lblDestination.text = dicArrPlace.value(forKey: "shortName") as? String
            }
            
            //Time & Distance
            let intDistance = dicSegment.value(forKey: "distance") as? Double
            let intTime = dicSegment.value(forKey: "transitDuration") as? Int
            let formatter = DateComponentsFormatter()
            formatter.allowedUnits = [.hour, .minute]
            formatter.unitsStyle = .abbreviated
            let strTime = formatter.string(from: TimeInterval(intTime! * 60))!
            detailCell.lblDuration.isHidden = true
            detailCell.lblLineCode.text = strTime
            detailCell.imageView?.image = UIImage(named: "WalkMarker.png")
            if intDistance! > 1 {
                detailCell.lblApproxPrice.text = "Approx \(intDistance ?? 0)" + "km"
            } else {
                detailCell.lblApproxPrice.text = "Approx \(intDistance ?? 0)" + "meters"
            }
        
            return detailCell
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return flCellHeight
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
