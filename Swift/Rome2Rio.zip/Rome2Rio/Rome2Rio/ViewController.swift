//
//  ViewController.swift
//  Rome2Rio
//
//  Created by EbitNHP-i1 on 28/07/18.
//  Copyright © 2018 EbitNHP-i1. All rights reserved.
//

import UIKit
import GooglePlaces
import Alamofire
import SwiftyJSON
enum Location
{
    case startLocation
    case destinationLocation
}
class ViewController: UIViewController,UITextFieldDelegate{
    @IBOutlet weak var txtSource: UITextField!
    @IBOutlet weak var txtDestination: UITextField!
    @IBOutlet weak var tblDestination: UITableView!
    @IBOutlet weak var tblSource: UITableView!
    var autoCompletePlacesData = [String]()
    var locationSelected = Location.startLocation
    var strSource = ""
    var strDestination = ""
    var suffix = ""
    var pref = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let str = "1 can (15 Ounces) White kidney beans, with liquid"
        if let rangeOfZero = str.range(of: "(", options: .backwards) {
            pref = String(str.prefix(upTo: rangeOfZero.lowerBound))
            print(pref)
        }
        if let rangeOfZero = str.range(of: ")", options: .backwards) {
            suffix = String(str.suffix(from: rangeOfZero.upperBound))
            print(suffix)
        }
        
        tblSource.isHidden = true
        tblDestination.isHidden = true
        // Do any additional setup after loading the view, typically from a nib.
    }
    @IBAction func txtSourceTap(_ sender: UITextField)
    {
        locationSelected = .startLocation
    }
    @IBAction func txtDestTap(_ sender: UITextField)
    {
        locationSelected = .destinationLocation
    }
    //MARK:- Textfield Delegate & Datasource
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if textField == txtSource
        {
            sourceTextFieldDidChange()
            return true
        }
        else
        {
            destTextFieldDidChange()
            return true
        }
    }
    func textFieldDidEndEditing(_ textField: UITextField) {
        if textField == txtSource
        {
            self.tblSource.isHidden = true
        }
        else
        {
            self.tblDestination.isHidden = true
        }
    }
    func textFieldShouldClear(_ textField: UITextField) -> Bool {
        if textField == txtSource
        {
            self.tblSource.isHidden = true
            return true
        }
        else
        {
            self.tblDestination.isHidden = true
            return true
        }
    }

    func sourceTextFieldDidChange()
    {
        let placesClient = GMSPlacesClient()
        
            placesClient.autocompleteQuery(txtSource.text!, bounds: nil, filter: nil, callback: { (results, error) in
                DispatchQueue.main.async
                    {
                        self.autoCompletePlacesData.removeAll()
                        if results != nil
                        {
                            for result in results!
                            {
                            self.autoCompletePlacesData.append(result.attributedFullText.string)
                                print(self.autoCompletePlacesData)
                            }
                            
                            print(self.autoCompletePlacesData)
                        }
                        if self.autoCompletePlacesData.count != 0
                        {
                            self.tblSource.isHidden = false
                        }
                        else
                        {
                            self.tblSource.isHidden = true
                        }
                        self.tblSource.reloadData()
                }
            })
    }
    func destTextFieldDidChange()
    {
        let placesClient = GMSPlacesClient()
        placesClient.autocompleteQuery(txtDestination.text!, bounds: nil, filter: nil, callback: { (results, error) in
            DispatchQueue.main.async
                {
                    self.autoCompletePlacesData.removeAll()
                    if results != nil
                    {
                        for result in results!
                        {
                            self.autoCompletePlacesData.append(result.attributedFullText.string)
                        }
                    }
                    if self.autoCompletePlacesData.count != 0
                    {
                        self.tblSource.isHidden = true
                        self.tblDestination.isHidden = false
                    }
                    else
                    {
                        self.tblSource.isHidden = true
                        self.tblDestination.isHidden = true
                    }
                    self.tblDestination.reloadData()
            }
        })
        
    }
    //MARK:- Get Direction
    @IBAction func btnGetDirection(_ sender: UIButton)
    {
        if txtSource.text != "" && txtDestination.text != ""
        {
            let oName = txtSource.text!
            let dName = txtDestination.text!
            let url: String = "http://free.rome2rio.com/api/1.4/json/Search?key=qLPLy3g8&oName=\(oName)&dName=\(dName)&currencyCode=INR"
            let strUrl: String = url.addingPercentEncoding(withAllowedCharacters: .urlFragmentAllowed)!
            let searchURL = URL(string: strUrl)
            
            Alamofire.request(searchURL!, method: .get, parameters: nil, encoding: URLEncoding.default, headers: nil).responseJSON
            { (response) in
                print(response.request!)  // original URL request
                print(response.response!) // HTTP URL response
                print(response.data!)     // server data
                print(response.result)    // result of response serialization

               if response.data != nil && response.value != nil
               {
                let dict = response.value as! NSDictionary
                let values = dict.value(forKeyPath: "routes.segments.path") as! NSArray
                let nav = self.storyboard?.instantiateViewController(withIdentifier: "SwipeVC") as! SwipeViewController
                nav.dicData = response.value as! NSDictionary
                nav.arrPath = values
                self.navigationController?.pushViewController(nav, animated: true)
               }
               else
               {
                self.presentAlert(title: "Something Wrong.", message: "Try different location.", actionTitle: "Ok")
               }
            }
        }
        else
        {
            presentAlert(title: "Enter locations.", message: "Enter both source and destination.", actionTitle: "Ok")
        }
    }
    func presentAlert(title: String, message: String, actionTitle: String)
    {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: actionTitle, style: .cancel, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
//MARK:- Table Delegate & Datasource
extension ViewController: UITableViewDataSource,UITableViewDelegate
{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return autoCompletePlacesData.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if tableView == tblSource
        {
            let cell = tableView.dequeueReusableCell(withIdentifier: "sourceCell", for: indexPath)
            cell.textLabel?.text = autoCompletePlacesData[indexPath.row]
            return cell
        }
        else
        {
            let cell = tableView.dequeueReusableCell(withIdentifier: "destinationCell", for: indexPath)
            cell.textLabel?.text = autoCompletePlacesData[indexPath.row]
            return cell
        }
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if tableView == tblSource
        {
            txtSource.text = autoCompletePlacesData[indexPath.row]
            print(txtSource.text!)
            tblSource.isHidden = true
        }
        else
        {
            txtDestination.text = autoCompletePlacesData[indexPath.row]
            print(txtDestination.text!)
            tblDestination.isHidden = true
        }
    }
}
