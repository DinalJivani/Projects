//
//  SwipeViewController.swift
//  Rome2Rio
//
//  Created by EbitNHP-i1 on 28/09/18.
//  Copyright © 2018 EbitNHP-i1. All rights reserved.
//

import UIKit
import GoogleMaps
class SwipeViewController: UIViewController {
    @IBOutlet weak var scrView: UIScrollView!
    @IBOutlet weak var mapView: GMSMapView!
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var collectionHeight: NSLayoutConstraint!
    
    var dicData = NSDictionary()
    var arrPath = NSArray()
    var arrPlace = NSArray()
    var arrPlaces = NSArray()
    var arrRoutes = NSArray()
    var arrPrice: [Any] = []
    var markerView = MarkerView()
    var arrSegments = NSArray()
    var collapaseHandlerArray = [String]()
    var tmpSegments = NSArray()
    var tmpSection = [String]()
    var tmpItems = [[String]]()
    var arrDeparture:[Any] = []
    var arrArrival:[Any] = []
    var arrVehicle: NSArray!
    var vehicle:[Any] = []
    var flCellHeight = CGFloat()
    var arrSegment = NSArray()
    override func viewDidLoad() {
        super.viewDidLoad()
        collectionHeight.constant = self.view.frame.height
        scrView.bounces = false
        collectionView.bounces = true
        
        arrPlace = dicData.value(forKey: "places") as! NSArray
        arrRoutes = dicData.value(forKey: "routes") as! NSArray
        
        //
        for i in 0..<arrRoutes.count {
            tmpSection.append("section\(i)")
        }
        
        tmpSegments = arrRoutes.value(forKey: "segments") as! NSArray
        for i in 0..<tmpSegments.count {
            var arrTmpSeg = [String]()
            let tmp = tmpSegments[i] as! NSArray
            for j in 0..<tmp.count {
                arrTmpSeg.append("Rows\(j)")
            }
            tmpItems.append(arrTmpSeg)
        }
        
        //
        
        arrVehicle = dicData.value(forKey: "vehicles") as! NSArray
        arrPlaces = dicData.value(forKey: "places") as! NSArray
        for i in 0..<arrRoutes.count
        {
            let dicSeg = arrRoutes[i] as! NSDictionary
            arrSegments = dicSeg.value(forKey: "segments") as! NSArray
            let path = arrSegments.value(forKey: "path") as! NSArray
            let depPlace = arrSegments.value(forKey: "depPlace") as! [Int]
            let arPlace = arrSegments.value(forKey: "arrPlace") as! [Int]
            let vehicl = arrSegments.value(forKey: "vehicle") as! [Int]
            let approxPrice = dicSeg.value(forKey: "indicativePrices") as! NSArray
            arrPath.adding(path)
            vehicle.append(vehicl)
            arrPrice.append(approxPrice)
            arrDeparture.append(depPlace)
            arrArrival.append(arPlace)
        }
        
        //Draw Source to Destination
        drawSourceDest()
    }
    
    func drawSourceDest() {
        //Draw Source to Destination
        let dicSource = arrPlace[0] as! NSDictionary
        let dicDestination = arrPlace[1] as! NSDictionary
        let path = GMSMutablePath()
        path.add(CLLocationCoordinate2DMake(dicSource.value(forKey: "lat") as! CLLocationDegrees, dicSource.value(forKey: "lng") as! CLLocationDegrees))
        path.add(CLLocationCoordinate2DMake(dicDestination.value(forKey: "lat") as! CLLocationDegrees, dicDestination.value(forKey: "lng") as! CLLocationDegrees))
        let polyLine = GMSPolyline(path: path)
        polyLine.strokeWidth = 5.0
        polyLine.map = mapView
        
        //Zoom Map
        let bound = GMSCoordinateBounds(coordinate: CLLocationCoordinate2DMake(dicSource.value(forKey: "lat") as! CLLocationDegrees, dicSource.value(forKey: "lng") as! CLLocationDegrees), coordinate: CLLocationCoordinate2DMake(dicDestination.value(forKey: "lat") as! CLLocationDegrees, dicDestination.value(forKey: "lng") as! CLLocationDegrees))
        mapView.animate(with: GMSCameraUpdate.fit(bound, withPadding: 50.0))
    }
    
    //MARK:- Convert view into image
    func imageWithView(view:UIView) -> UIImage
    {
        let size = CGSize(width: view.bounds.size.width, height: view.bounds.size.height)
        UIGraphicsBeginImageContextWithOptions(size, false, 0.0)
        view.layer.render(in: UIGraphicsGetCurrentContext()!)
        let image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return image!
    }
    
    //MARK:- Marker Functions
    func lastMarker(markerTitle: String) -> UIImage
    {
        let mView = markerView
        mView.lblRouteName.text = markerTitle
        mView.imgMarker.image = nil
        mView.contentView.sizeToFit()
        mView.lblRouteName.sizeToFit()
        
        let subView = UIView(frame: CGRect(x: 0, y: 0, width: mView.lblRouteName.bounds.size.width+30, height: 30))
        subView.backgroundColor = UIColor.clear
        subView.sizeToFit()
        subView.addSubview(mView)
        
        let img = imageWithView(view: subView)
        return img
    }
    
    //MARK: - objc Methods
    @objc func HandleheaderButton(sender: UIButton, tblView: UITableView) {
        if let buttonTitle = sender.title(for: .normal) {
            if buttonTitle == "Show"{
                //if yes
                self.collapaseHandlerArray.append(self.tmpSection[sender.tag])
                sender.setTitle("Hide", for: .normal)
            }
            else {
                //if no
                while self.collapaseHandlerArray.contains(self.tmpSection[sender.tag]){
                    if let itemToRemoveIndex = self.collapaseHandlerArray.index(of: self.tmpSection[sender.tag]) {
                        //remove title of header from array
                        self.collapaseHandlerArray.remove(at: itemToRemoveIndex)
                        sender.setTitle("Show", for: .normal)
                    }
                }
            }
        }
      collectionView.reloadData()
        
        //reload section
//        tblView.reloadSections(IndexSet(integer: sender.tag), with: .none)
    }
    
    @objc func drawAllRoute(sender: UIButton) {

        let points = arrPath[sender.tag] as! NSArray
        let veh = vehicle[sender.tag] as! NSArray
        let arDepart = arrDeparture[sender.tag] as! NSArray
        let arArriv = arrArrival[sender.tag] as! NSArray
        var path: GMSPath!
        var preCoordinate: CLLocationCoordinate2D!
        var foot:Int!
        
        mapView.clear()
        for i in 0..<points.count
        {
            let vType = veh[i] as! Int
            let arPlace = arDepart[i] as! Int
            let drPlace = arArriv[i] as! Int
            let tempType = arrVehicle[vType] as! NSDictionary
            let tmpAPlaces = arrPlaces[arPlace] as! NSDictionary
            //let tmpDPlaces = arrPlaces[drPlace] as! NSDictionary
            if tempType.value(forKey: "kind") as! String == "foot"
            {
                //Walking Direction dashed lines
                let point = points[i] as! String
                path = GMSPath.init(fromEncodedPath: point)
                let polyline = GMSPolyline.init(path: path)
                let strokeStyles = [GMSStrokeStyle.solidColor(.black), GMSStrokeStyle.solidColor(.clear)]
                let strokeLengths = [NSNumber(value: 5), NSNumber(value: 5)]
                if let path = polyline.path
                {
                    polyline.spans = GMSStyleSpans(path, strokeStyles, strokeLengths, .rhumb)
                }
                polyline.strokeWidth = 8
                polyline.map = mapView
                //Marker
                let wMarker = GMSMarker()
                let mTitle = tmpAPlaces.value(forKey: "shortName") as? String
                let mIcon = markerImage(markerTitle: mTitle!, markerImage: UIImage(named: "WalkMarker.png")!)
                wMarker.icon = mIcon
                wMarker.position = path.coordinate(at: 0)
                wMarker.map = mapView
                foot = i
            }
            else
            {
                if points[i] as? String != nil || i == foot
                {
                    let point = points[i] as! String
                    path = GMSPath.init(fromEncodedPath: point)
                    
                    //Zoom Map
                    let zoomPoint = points[0] as! String
                    let zoomPath = GMSPath.init(fromEncodedPath: zoomPoint)
                    let bounds = GMSCoordinateBounds(path: zoomPath!)
                    mapView.animate(with: GMSCameraUpdate.fit(bounds, withPadding: 50.0))
                    
                    //Polyline
                    let polyline = GMSPolyline.init(path: path)
                    polyline.strokeWidth = 8
                    let strVehiName = tempType.value(forKey: "kind") as! String
                    print(strVehiName)
                    if strVehiName == "helicopter"
                    {
                        polyline.strokeColor = UIColor(red: 102/255, green: 67/255, blue: 129/255, alpha: 1)
                    }else if strVehiName == "car"
                    {
                        polyline.strokeColor = UIColor(red: 85/255, green: 85/255, blue: 85/255, alpha: 1)
                    }else if strVehiName == "bus"
                    {
                        polyline.strokeColor = UIColor(red: 224/255, green: 102/255, blue: 34/255, alpha: 1)
                    }else if strVehiName == "taxi"
                    {
                        polyline.strokeColor = UIColor(red: 255/255, green: 163/255, blue: 2/255, alpha: 1)
                    }else if strVehiName == "rideshare"
                    {
                        polyline.strokeColor = UIColor(red: 121/255, green: 195/255, blue: 66/255, alpha: 1)
                    }else if strVehiName == "shuttle"
                    {
                        polyline.strokeColor = UIColor(red: 220/255, green: 1/255, blue: 52/255, alpha: 1)
                    }else if strVehiName == "towncar"
                    {
                        polyline.strokeColor = UIColor(red: 255/255, green: 163/255, blue: 2/255, alpha: 1)
                    }else if strVehiName == "train"
                    {
                        polyline.strokeColor = UIColor(red: 104/255, green: 58/255, blue: 123/255, alpha: 1.0)
                    }else if strVehiName == "tram"
                    {
                        polyline.strokeColor =  UIColor(red: 104/255, green: 58/255, blue: 123/255, alpha: 1.0)
                    }else if strVehiName == "cablecar"
                    {
                        polyline.strokeColor = UIColor(red: 104/255, green: 58/255, blue: 123/255, alpha: 1.0)
                    }else if strVehiName == "subway"
                    {
                        polyline.strokeColor = UIColor(red: 104/255, green: 58/255, blue: 123/255, alpha: 1.0)
                    }else if strVehiName == "ferry"
                    {
                        polyline.strokeColor = UIColor(red: 99/255, green: 139/255, blue: 241/255, alpha: 1)
                    }else if strVehiName == "animal"
                    {
                        polyline.strokeColor = UIColor.black
                    }else if strVehiName == "bicycle"
                    {
                        polyline.strokeColor =  UIColor(red: 107/255, green: 186/255, blue: 166/255, alpha: 1.0)
                    }
                    polyline.map = self.mapView
                    
                    //Marker
                    if points.count == 1
                    {
                        //Start Marker
                        let mLat = tmpAPlaces.value(forKey: "lat") as! Double
                        let mLong = tmpAPlaces.value(forKey: "lng") as! Double
                        let mCoord = CLLocationCoordinate2DMake(mLat, mLong)
                        
                        let vehiName = tempType.value(forKey: "kind") as! String
                        let mTitle =  tmpAPlaces.value(forKey: "shortName") as? String
                        
                        let marker = GMSMarker()
                        let mIcon = markerImage(markerTitle: mTitle!, markerImage: UIImage(named: vehiName+".png")!)
                        marker.position = mCoord
                        marker.icon = mIcon
                        marker.map = mapView
                        
                        //End Marker
                        let endPosition = arArriv.lastObject as! Int
                        let dicPlace = arrPlaces[endPosition] as! NSDictionary
                        let eLat = dicPlace.value(forKey: "lat") as! Double
                        let eLong = dicPlace.value(forKey: "lng") as! Double
                        let eCoord = CLLocationCoordinate2DMake(eLat, eLong)
                        let eMarker = GMSMarker()
                        let emTitle = dicPlace.value(forKey: "shortName") as? String
                        var emIcon = lastMarker(markerTitle: emTitle!)
                        emIcon = emIcon.withAlignmentRectInsets(UIEdgeInsetsMake(5, 30, 0, 0))
                        eMarker.icon = emIcon
                        eMarker.position = eCoord
                        eMarker.map = mapView
                    }
                    else
                    {
                        //Marker
                        let mLat = tmpAPlaces.value(forKey: "lat") as! Double
                        let mLong = tmpAPlaces.value(forKey: "lng") as! Double
                        let mCoord = CLLocationCoordinate2DMake(mLat, mLong)
                        let marker = GMSMarker()
                        let mTitle = tmpAPlaces.value(forKey: "shortName") as? String
                        let vehiName = tempType.value(forKey: "kind") as! String
                        let mIcon = markerImage(markerTitle: mTitle!, markerImage: UIImage(named: vehiName+".png")!)
                        marker.icon = mIcon
                        marker.position = mCoord
                        marker.map = mapView
                        
                        //End Marker
                        let endPosition = arArriv.lastObject ?? 1
                        let diclPlace = arrPlaces[endPosition as! Int] as! NSDictionary
                        let eLat = diclPlace.value(forKey: "lat") as! Double
                        let eLong = diclPlace.value(forKey: "lng") as! Double
                        let eCoord = CLLocationCoordinate2DMake(eLat, eLong)
                        
                        let eMarker = GMSMarker()
                        let eMarkerTitle = diclPlace.value(forKey: "shortName") as? String
                        var emIcon = lastMarker(markerTitle: eMarkerTitle!)
                        emIcon = emIcon.withAlignmentRectInsets(UIEdgeInsetsMake(5, 30, 0, 0))
                        eMarker.icon = emIcon
                        eMarker.position = eCoord
                        eMarker.map = mapView
                        
                    }
                }
                else
                {
                    for k in 0..<path.count()
                    {
                        preCoordinate = path.coordinate(at: k)
                    }
                    let dicFlight = arrPlaces[drPlace] as! NSDictionary
                    print(dicFlight)
                    let flLat = dicFlight.value(forKey: "lat") as! Double
                    let flLong = dicFlight.value(forKey: "lng") as! Double
                    let flCoord = CLLocationCoordinate2DMake(flLat, flLong)
                    //Flight Marker
                    let fMarker = GMSMarker()
                    let fTitle = tmpAPlaces.value(forKey: "shortName") as? String
                    let fIcon = markerImage(markerTitle: fTitle!, markerImage: #imageLiteral(resourceName: "FlightMarker.png"))
                    fMarker.position = preCoordinate
                    fMarker.icon = fIcon
                    fMarker.map = mapView
                    //Flight polyline
                    let flightPath = GMSMutablePath()
                    flightPath.add(preCoordinate)
                    flightPath.add(flCoord)
                    let polyline = GMSPolyline(path: flightPath)
                    polyline.strokeWidth = 8.0
                    polyline.strokeColor = UIColor(red: 5/255, green: 194/255, blue: 156/255, alpha: 1.0)
                    polyline.map = mapView
                }
            }
        }
    }
    
    func markerImage(markerTitle: String, markerImage: UIImage) -> UIImage
    {
        let mView = markerView
        mView.lblRouteName.text = markerTitle
        mView.imgMarker.image = markerImage
        mView.contentView.sizeToFit()
        mView.lblRouteName.sizeToFit()
        
        let subView = UIView(frame: CGRect(x: 0, y: 0, width: mView.lblRouteName.bounds.size.width+30, height: 30))
        subView.backgroundColor = UIColor.clear
        subView.sizeToFit()
        subView.addSubview(mView)
        
        let img = imageWithView(view: subView)
        return img
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}
//MARK:- ColletctionView Delegate & Datasource
extension SwipeViewController : UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if self.arrRoutes.count > 0 {
            return arrRoutes.count
        } else {
            return 0
        }
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "collCell", for: indexPath) as! RouteCollectionViewCell
        cell.tblView.reloadData()
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: collectionView.frame.size.width, height: collectionView.frame.size.height)
    }

}

//MARK:- TableView Delegate & Datasource
extension SwipeViewController : UITableViewDataSource,UITableViewDelegate {
    func numberOfSections(in collectionView: UICollectionView) -> Int {
//        if self.arrRoutes.count > 0 {
//            return arrRoutes.count
//        } else {
//            return 0
//        }
        return 1
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 162.0
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerCell = tableView.dequeueReusableCell(withIdentifier: "headerCell") as! HeaderTableViewCell
        if arrRoutes.count > 0
        {
            if self.collapaseHandlerArray.contains(self.tmpSection[section]){
                //if its opened
                headerCell.btnShowHide.setTitle("Hide", for: .normal)
            }
            else{
                //if closed
                headerCell.btnShowHide.setTitle("Show", for: .normal)
            }
            
            headerCell.btnPlan.tag = section
            headerCell.btnPlan.addTarget(self, action: #selector(SwipeViewController.HandleheaderButton(sender:tblView:)), for: .touchUpInside)
            headerCell.btnShowHide.tag = section
            headerCell.btnShowHide.addTarget(self, action: #selector(SwipeViewController.HandleheaderButton(sender:tblView:)), for: .touchUpInside)
            headerCell.btnDrawRoute.tag = section
            headerCell.btnDrawRoute.addTarget(self, action: #selector(SwipeViewController.drawAllRoute(sender:)), for: .touchUpInside)
            
            //Route Name
            let route = arrRoutes[section] as! NSDictionary
            
            //Counting Time duration
            let interval = route.value(forKey: "totalDuration") as? Int
            let formatter = DateComponentsFormatter()
            formatter.allowedUnits = [.hour, .minute]
            formatter.unitsStyle = .abbreviated
            let formattedString = formatter.string(from: TimeInterval(interval! * 60))!
            
            //Approx Price
            let price = arrPrice[section] as! NSArray
            let priceLow = price.value(forKey: "priceLow") as! NSArray
            let priceHigh = price.value(forKey: "priceHigh") as! NSArray
            
            if "\(priceLow[0])" == "<null>"
            {
                let arrCarPrice = arrPrice[section] as! NSArray
                let approxPrice = arrCarPrice.value(forKey: "price") as! NSArray
                headerCell.lblApproxPrice.text = "Approx Price: " + "₹ " + "\(approxPrice[0])" + " - " + "₹ " + "\(approxPrice[2])"
            }
            else
            {
                headerCell.lblApproxPrice.text = "Approx Price: " + "₹ " + "\(priceLow[0])" + " - " + "₹ " + "\(priceHigh[0])"
            }
            //Cell Assign
            headerCell.lblRouteName.text = route.value(forKey: "name") as? String
            headerCell.lblTime.text = formattedString
            return headerCell.contentView
        }
        else
        {
            return headerCell.contentView
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if self.collapaseHandlerArray.contains(self.tmpSection[section]){
            return tmpItems[section].count
        }
        else{
            return 0
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        print(indexPath.row)
        let arrRoute = dicData.value(forKey: "routes") as! NSArray
        let dicRoute = arrRoute[indexPath.section] as! NSDictionary
        arrSegment = dicRoute.value(forKey: "segments") as! NSArray
        
        let arrTmpSeg = tmpSegments[indexPath.section] as! NSArray
        let dicTmpSeg = arrTmpSeg[indexPath.row] as! NSDictionary
        let intVehicleNo = dicTmpSeg.value(forKey: "vehicle") as? Int
        let arrVehicle = dicData.value(forKey: "vehicles") as! NSArray
        var tmpDicVehicle  = NSDictionary()
        var tmpdicSegment = NSDictionary()
        var strVehicleType = String()
        if intVehicleNo != nil {
            tmpDicVehicle = arrVehicle[intVehicleNo!] as! NSDictionary
            strVehicleType = tmpDicVehicle.value(forKey: "name") as! String
        }
        
        tmpdicSegment = arrSegment[indexPath.row] as! NSDictionary
        
        if strVehicleType != "Walk" {
            let detailCell = tableView.dequeueReusableCell(withIdentifier: "detailCell", for: indexPath) as! DetailTableViewCell
            detailCell.accessoryType = .disclosureIndicator
            
            let dicSegment = arrTmpSeg[indexPath.row] as! NSDictionary
            //Counting Time Duration
            let interval = dicSegment.value(forKey: "transitDuration") as? Int
            let formatter = DateComponentsFormatter()
            formatter.allowedUnits = [.hour, .minute]
            formatter.unitsStyle = .abbreviated
            let formattedString = formatter.string(from: TimeInterval(interval! * 60))!
            detailCell.lblDuration.text = formattedString
            
            // Counting Approx Price
            if (dicSegment.value(forKey: "indicativePrices") as? NSArray) != nil {
                let arrPrice = dicSegment.value(forKey: "indicativePrices") as! NSArray
                let arrPriceLow = arrPrice.value(forKey: "priceLow") as! NSArray
                let arrPriceHigh = arrPrice.value(forKey: "priceHigh") as! NSArray
                if "\(arrPriceLow[0])" == "<null>" {
                    if arrPrice[0] as? NSDictionary != nil {
                        if arrPrice.count > 1 {
                            let dicPriceLow = arrPrice[0] as! NSDictionary
                            let dicPriceHigh = arrPrice[2] as! NSDictionary
                            let intPriceLow = dicPriceLow.value(forKey: "price") as! Int
                            let intPriceHigh = dicPriceHigh.value(forKey: "price") as! Int
                            detailCell.lblApproxPrice.text = "₹ " + "\(intPriceLow)" + " - " + "₹ " + "\(intPriceHigh)"
                        } else {
                            let dicPrice = arrPrice[0] as! NSDictionary
                            detailCell.lblApproxPrice.text = "₹ " + "\(dicPrice.value(forKey: "price") as!Int)"
                        }
                        
                    } else {
                        detailCell.lblApproxPrice.text = ""
                    }
                    
                    
                } else {
                    detailCell.lblApproxPrice.text = "₹ " + "\(arrPriceLow[0])" + " - " + "₹ " + "\(arrPriceHigh[0])"
                }
            }
            
            // Sorce And Destination
            let intDepPlace = dicSegment.value(forKey: "depPlace") as? Int
            let intArrPlace = dicSegment.value(forKey: "arrPlace") as? Int
            let arrPlaces = dicData.value(forKey: "places") as! NSArray
            let dicArrPlace = arrPlaces[intArrPlace!] as! NSDictionary
            let dicDepPlace = arrPlaces[intDepPlace!] as! NSDictionary
            
            if dicDepPlace.value(forKey: "code") != nil {
                let strShortName = dicDepPlace.value(forKey: "shortName") as? String
                if (strShortName?.contains("("))! {
                    detailCell.lblSource.text = dicDepPlace.value(forKey: "shortName") as? String
                } else {
                    detailCell.lblSource.text = strShortName!+"(\(dicDepPlace.value(forKey: "code") ?? ""))"
                }
            } else {
                detailCell.lblSource.text = dicDepPlace.value(forKey: "shortName") as? String
            }
            
            if dicArrPlace.value(forKey: "code") != nil {
                let strShortName = dicArrPlace.value(forKey: "shortName") as? String
                if (strShortName?.contains("("))! {
                    detailCell.lblDestination.text = dicArrPlace.value(forKey: "shortName") as? String
                } else {
                    detailCell.lblDestination.text = strShortName!+"(\(dicArrPlace.value(forKey: "code") ?? ""))"
                }
                
            } else {
                detailCell.lblDestination.text = dicArrPlace.value(forKey: "shortName") as? String
            }
            
            //Change View Color
            let arrVehicle = dicData.value(forKey: "vehicles") as! NSArray
            let intVehicle = dicSegment.value(forKey: "vehicle") as? Int
            let dicVehicle = arrVehicle[intVehicle!] as! NSDictionary
            let strVehicleType = dicVehicle.value(forKey: "name") as? String
            detailCell.vwSource.clipsToBounds = true
            detailCell.vwSource.layer.cornerRadius = detailCell.vwSource.bounds.size.width / 2
            detailCell.vwSource.layer.borderWidth = 5.0
            
            detailCell.vwDestination.clipsToBounds = true
            detailCell.vwDestination.layer.cornerRadius = detailCell.vwDestination.bounds.size.width / 2
            detailCell.vwDestination.layer.borderWidth = 5.0
            
            if strVehicleType == "Helicopter"
            {
                detailCell.imgVehicle.image = UIImage(named: "helicopter.png")
                detailCell.vwDestination.layer.borderColor = UIColor(red: 102/255, green: 67/255, blue: 129/255, alpha: 1).cgColor
                detailCell.vwSource.layer.borderColor = UIColor(red: 102/255, green: 67/255, blue: 129/255, alpha: 1).cgColor
                detailCell.vwRoute.backgroundColor = UIColor(red: 102/255, green: 67/255, blue: 129/255, alpha: 1)
            } else if strVehicleType == "Car"
            {
                detailCell.imgVehicle.image = UIImage(named: "car.png")
                detailCell.vwDestination.layer.borderColor = UIColor(red: 85/255, green: 85/255, blue: 85/255, alpha: 1).cgColor
                detailCell.vwSource.layer.borderColor = UIColor(red: 85/255, green: 85/255, blue: 85/255, alpha: 1).cgColor
                detailCell.vwRoute.backgroundColor = UIColor(red: 85/255, green: 85/255, blue: 85/255, alpha: 1)
            } else if strVehicleType == "Bus"
            {
                detailCell.imgVehicle.image = UIImage(named: "bus.png")
                detailCell.vwDestination.layer.borderColor = UIColor(red: 224/255, green: 102/255, blue: 34/255, alpha: 1).cgColor
                detailCell.vwSource.layer.borderColor = UIColor(red: 224/255, green: 102/255, blue: 34/255, alpha: 1).cgColor
                detailCell.vwRoute.backgroundColor = UIColor(red: 224/255, green: 102/255, blue: 34/255, alpha: 1)
            } else if strVehicleType == "Taxi"
            {
                detailCell.imgVehicle.image = UIImage(named: "taxi.png")
                detailCell.vwDestination.layer.borderColor = UIColor(red: 255/255, green: 163/255, blue: 2/255, alpha: 1).cgColor
                detailCell.vwSource.layer.borderColor = UIColor(red: 255/255, green: 163/255, blue: 2/255, alpha: 1).cgColor
                detailCell.vwRoute.backgroundColor = UIColor(red: 255/255, green: 163/255, blue: 2/255, alpha: 1)
            } else if strVehicleType == "Rideshare"
            {
                detailCell.imgVehicle.image = UIImage(named: "rideshare.png")
                detailCell.vwDestination.layer.borderColor = UIColor(red: 121/255, green: 195/255, blue: 66/255, alpha: 1).cgColor
                detailCell.vwSource.layer.borderColor = UIColor(red: 121/255, green: 195/255, blue: 66/255, alpha: 1).cgColor
                detailCell.vwRoute.backgroundColor = UIColor(red: 121/255, green: 195/255, blue: 66/255, alpha: 1)
            } else if strVehicleType == "Shuttle"
            {
                detailCell.imgVehicle.image = UIImage(named: "shuttle.png")
                detailCell.vwDestination.layer.borderColor = UIColor(red: 220/255, green: 1/255, blue: 52/255, alpha: 1).cgColor
                detailCell.vwSource.layer.borderColor = UIColor(red: 220/255, green: 1/255, blue: 52/255, alpha: 1).cgColor
                detailCell.vwRoute.backgroundColor = UIColor(red: 220/255, green: 1/255, blue: 52/255, alpha: 1)
            } else if strVehicleType == "Towncar"
            {
                detailCell.imgVehicle.image = UIImage(named: "towncar.png")
                detailCell.vwDestination.layer.borderColor = UIColor(red: 255/255, green: 163/255, blue: 2/255, alpha: 1).cgColor
                detailCell.vwSource.layer.borderColor = UIColor(red: 255/255, green: 163/255, blue: 2/255, alpha: 1).cgColor
                detailCell.vwRoute.backgroundColor = UIColor(red: 255/255, green: 163/255, blue: 2/255, alpha: 1)
            } else if strVehicleType == "Train"
            {
                detailCell.imgVehicle.image = UIImage(named: "train.png")
                detailCell.vwDestination.layer.borderColor = UIColor(red: 104/255, green: 58/255, blue: 123/255, alpha: 1.0).cgColor
                detailCell.vwSource.layer.borderColor = UIColor(red: 104/255, green: 58/255, blue: 123/255, alpha: 1.0).cgColor
                detailCell.vwRoute.backgroundColor = UIColor(red: 104/255, green: 58/255, blue: 123/255, alpha: 1.0)
            } else if strVehicleType == "Eurotunnel"
            {
                detailCell.imgVehicle.image = UIImage(named: "train.png")
                detailCell.vwDestination.layer.borderColor = UIColor(red: 104/255, green: 58/255, blue: 123/255, alpha: 1.0).cgColor
                detailCell.vwSource.layer.borderColor = UIColor(red: 104/255, green: 58/255, blue: 123/255, alpha: 1.0).cgColor
                detailCell.vwRoute.backgroundColor = UIColor(red: 104/255, green: 58/255, blue: 123/255, alpha: 1.0)
            }
            else if strVehicleType == "Tram"
            {
                detailCell.imgVehicle.image = UIImage(named: "tram.png")
                detailCell.vwDestination.layer.borderColor = UIColor(red: 104/255, green: 58/255, blue: 123/255, alpha: 1.0).cgColor
                detailCell.vwSource.layer.borderColor = UIColor(red: 104/255, green: 58/255, blue: 123/255, alpha: 1.0).cgColor
                detailCell.vwRoute.backgroundColor =  UIColor(red: 104/255, green: 58/255, blue: 123/255, alpha: 1.0)
            } else if strVehicleType == "Cablecar"
            {
                detailCell.imgVehicle.image = UIImage(named: "cablecar.png")
                detailCell.vwDestination.layer.borderColor = UIColor(red: 104/255, green: 58/255, blue: 123/255, alpha: 1.0).cgColor
                detailCell.vwSource.layer.borderColor = UIColor(red: 104/255, green: 58/255, blue: 123/255, alpha: 1.0).cgColor
                detailCell.vwRoute.backgroundColor = UIColor(red: 104/255, green: 58/255, blue: 123/255, alpha: 1.0)
            } else if strVehicleType == "Subway"
            {
                detailCell.imgVehicle.image = UIImage(named: "subway.png")
                detailCell.vwDestination.layer.borderColor = UIColor(red: 104/255, green: 58/255, blue: 123/255, alpha: 1.0).cgColor
                detailCell.vwSource.layer.borderColor = UIColor(red: 104/255, green: 58/255, blue: 123/255, alpha: 1.0).cgColor
                detailCell.vwRoute.backgroundColor = UIColor(red: 104/255, green: 58/255, blue: 123/255, alpha: 1.0)
            } else if strVehicleType == "Tube" {
                detailCell.imgVehicle.image = UIImage(named: "subway.png")
                detailCell.vwDestination.layer.borderColor = UIColor(red: 104/255, green: 58/255, blue: 123/255, alpha: 1.0).cgColor
                detailCell.vwSource.layer.borderColor = UIColor(red: 104/255, green: 58/255, blue: 123/255, alpha: 1.0).cgColor
                detailCell.vwRoute.backgroundColor = UIColor(red: 104/255, green: 58/255, blue: 123/255, alpha: 1.0)
            } else if strVehicleType == "Ferry" {
                detailCell.imgVehicle.image = UIImage(named: "ferry.png")
                detailCell.vwDestination.layer.borderColor = UIColor(red: 99/255, green: 139/255, blue: 241/255, alpha: 1).cgColor
                detailCell.vwSource.layer.borderColor = UIColor(red: 99/255, green: 139/255, blue: 241/255, alpha: 1).cgColor
                detailCell.vwRoute.backgroundColor = UIColor(red: 99/255, green: 139/255, blue: 241/255, alpha: 1)
            } else if strVehicleType == "car ferry" {
                detailCell.imgVehicle.image = UIImage(named: "ferry.png")
                detailCell.vwDestination.layer.borderColor = UIColor(red: 99/255, green: 139/255, blue: 241/255, alpha: 1).cgColor
                detailCell.vwSource.layer.borderColor = UIColor(red: 99/255, green: 139/255, blue: 241/255, alpha: 1).cgColor
                detailCell.vwRoute.backgroundColor = UIColor(red: 99/255, green: 139/255, blue: 241/255, alpha: 1)
            }
            else if strVehicleType == "Animal"
            {
                detailCell.imgVehicle.image = UIImage(named: "animal.png")
                detailCell.vwDestination.layer.borderColor = UIColor.black.cgColor
                detailCell.vwSource.layer.borderColor = UIColor.black.cgColor
                detailCell.vwRoute.backgroundColor = UIColor.black
            } else if strVehicleType == "Bicycle"
            {
                detailCell.imgVehicle.image = UIImage(named: "bicycle.png")
                detailCell.vwDestination.layer.borderColor = UIColor(red: 107/255, green: 186/255, blue: 166/255, alpha: 1.0).cgColor
                detailCell.vwSource.layer.borderColor = UIColor(red: 107/255, green: 186/255, blue: 166/255, alpha: 1.0).cgColor
                detailCell.vwRoute.backgroundColor =  UIColor(red:
                    107/255, green: 186/255, blue: 166/255, alpha: 1.0)
            } else if strVehicleType == "Plane" {
                detailCell.imgVehicle.image = UIImage(named: "FlightMarker.png")
                detailCell.vwDestination.layer.borderColor = UIColor(red: 5/255, green: 194/255, blue: 156/255, alpha: 1.0).cgColor
                detailCell.vwSource.layer.borderColor = UIColor(red: 5/255, green: 194/255, blue: 156/255, alpha: 1.0).cgColor
                detailCell.vwRoute.backgroundColor =  UIColor(red: 5/255, green: 194/255, blue: 156/255, alpha: 1.0)
            } else {
                
            }
            flCellHeight = 175
            return detailCell
        } else {
            let walkCell = tableView.dequeueReusableCell(withIdentifier: "walkCell", for: indexPath) as! WalkTableViewCell
            walkCell.accessoryType = .disclosureIndicator
            
            if strVehicleType == "Walk" {
                
                let radiusFloat = walkCell.vwFirst.bounds.size.width / 2
                walkCell.vwFirst.clipsToBounds = true
                walkCell.vwSecond.clipsToBounds = true
                walkCell.vwThird.clipsToBounds = true
                walkCell.vwForth.clipsToBounds = true
                walkCell.vwFirst.layer.cornerRadius = radiusFloat
                walkCell.vwSecond.layer.cornerRadius = radiusFloat
                walkCell.vwThird.layer.cornerRadius = radiusFloat
                walkCell.vwForth.layer.cornerRadius = radiusFloat
                
                let intDistance = tmpdicSegment.value(forKey: "distance") as? Double
                let intMeter = Int(intDistance! * 1000)
                let intTime = tmpdicSegment.value(forKey: "transitDuration") as? Int
                let formatter = DateComponentsFormatter()
                formatter.allowedUnits = [.hour, .minute]
                formatter.unitsStyle = .abbreviated
                let strTime = formatter.string(from: TimeInterval(intTime! * 60))!
                walkCell.lblTime.text = strTime
                walkCell.imageView?.image = UIImage(named: "WalkMarker.png")
                if intDistance! > 1 {
                    walkCell.lblDistance.text = "Approx \(intDistance ?? 0)" + "km"
                } else {
                    walkCell.lblDistance.text = "Approx \(intMeter)" + " meters"
                }
            }
            flCellHeight = 63
            return walkCell
        }
    }
}
