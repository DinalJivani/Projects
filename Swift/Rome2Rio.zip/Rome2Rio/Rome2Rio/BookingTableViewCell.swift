//
//  BookingTableViewCell.swift
//  Rome2Rio
//
//  Created by EbitNHP-i1 on 26/09/18.
//  Copyright © 2018 EbitNHP-i1. All rights reserved.
//

import UIKit

class BookingTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
