//
//  WalkTableViewCell.swift
//  Rome2Rio
//
//  Created by EbitNHP-i1 on 21/09/18.
//  Copyright © 2018 EbitNHP-i1. All rights reserved.
//

import UIKit

class WalkTableViewCell: UITableViewCell {

    @IBOutlet weak var lblTime: UILabel!
    @IBOutlet weak var lblDistance: UILabel!
    @IBOutlet weak var vwFirst: UIView!
    @IBOutlet weak var vwSecond: UIView!
    @IBOutlet weak var vwThird: UIView!
    @IBOutlet weak var vwForth: UIView!
    @IBOutlet weak var imgWalk: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
