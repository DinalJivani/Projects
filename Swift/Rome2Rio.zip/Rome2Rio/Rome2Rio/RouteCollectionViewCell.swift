//
//  RouteCollectionViewCell.swift
//  Rome2Rio
//
//  Created by EbitNHP-i1 on 28/09/18.
//  Copyright © 2018 EbitNHP-i1. All rights reserved.
//

import UIKit

class RouteCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var tblView: UITableView!
    
    override func layoutSubviews() {
        super.layoutSubviews()
        tblView.estimatedRowHeight = 63.0
        tblView.rowHeight = UITableViewAutomaticDimension
        tblView.tableFooterView = UIView()
        
        //For Non-Sticky header
        let dummyViewHeight = CGFloat(160)
        tblView.tableHeaderView = UIView(frame: CGRect(x: 0, y: 0, width: tblView.bounds.size.width, height: dummyViewHeight))
        tblView.contentInset = UIEdgeInsetsMake(-dummyViewHeight, 0, 0, 0)
        
        //Register Cell
        let nibDetail = UINib(nibName: "DetailTableViewCell", bundle: nil)
        tblView.register(nibDetail, forCellReuseIdentifier: "detailCell")
        
        let nibHeader = UINib(nibName: "HeaderTableViewCell", bundle: nil)
        tblView.register(nibHeader, forCellReuseIdentifier: "headerCell")
        
        let nibRouteDetail = UINib(nibName: "RouteDetailTableViewCell", bundle: nil)
        tblView.register(nibRouteDetail, forCellReuseIdentifier: "routeDetailCell")
        
        let nibWalk = UINib(nibName: "WalkTableViewCell", bundle: nil)
        tblView.register(nibWalk, forCellReuseIdentifier: "walkCell")
    }
}
