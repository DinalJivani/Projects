//
//  ResultTableViewCell.swift
//  Rome2Rio
//
//  Created by EbitNHP-i1 on 30/07/18.
//  Copyright © 2018 EbitNHP-i1. All rights reserved.
//

import UIKit

class ResultTableViewCell: UITableViewCell {
    @IBOutlet weak var lblRouteName: UILabel!
    @IBOutlet weak var lblApproxPrice: UILabel!
    @IBOutlet weak var lblTime: UILabel!
    @IBOutlet weak var viewRoute: UIView!
    @IBOutlet weak var viewPrice: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
